import json
from pathlib import Path
from flask import jsonify, abort
from backend.app import app
SAMPLES=json.loads((Path(__file__).parent/'train_samples.json').read_text())
def train_demo(use_case):
    if use_case not in SAMPLES: abort(404)
    return jsonify(SAMPLES[use_case])
app.view_functions['demo']=train_demo
