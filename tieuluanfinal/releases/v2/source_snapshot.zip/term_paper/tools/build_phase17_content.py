"""Package the six traceable visual assets used by Chapter 5."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


WORKSPACE = Path(__file__).resolve().parents[2]
SOURCE_ROOT = WORKSPACE / "term_paper/knowledge_rag/artifacts/figures"
DESTINATION = WORKSPACE / "term_paper/report/assets/ch5_knowledge_rag"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_dataset_overview(output: Path) -> None:
    sources = [
        ("MedQuAD: nhóm loại câu hỏi", SOURCE_ROOT / "phase11/medquad_question_types.png"),
        ("FinQA: phân bố split", SOURCE_ROOT / "phase11/finqa_split_distribution.png"),
        ("Wikidata: phân bố claim", SOURCE_ROOT / "phase11/wikidata_claim_distribution.png"),
    ]
    opened = [(label, Image.open(path).convert("RGB")) for label, path in sources]
    target_width = 1800
    margin = 48
    label_height = 54
    resized: list[tuple[str, Image.Image]] = []
    for label, image in opened:
        content_width = target_width - 2 * margin
        height = round(image.height * content_width / image.width)
        resized.append((label, image.resize((content_width, height), Image.Resampling.LANCZOS)))
    canvas_height = margin + sum(label_height + image.height + margin for _, image in resized)
    canvas = Image.new("RGB", (target_width, canvas_height), "white")
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.load_default(size=30)
    y = margin
    for label, image in resized:
        draw.text((margin, y), label, fill="#17365D", font=font)
        y += label_height
        canvas.paste(image, (margin, y))
        y += image.height + margin
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output, format="PNG", dpi=(200, 200), optimize=True)


def main() -> int:
    DESTINATION.mkdir(parents=True, exist_ok=True)
    overview = DESTINATION / "ch5_dataset_overview.png"
    build_dataset_overview(overview)

    copies = {
        SOURCE_ROOT / "phase13/graph_schema.svg": DESTINATION / "ch5_graph_schema.svg",
        SOURCE_ROOT / "phase15/test_recall_at_5.svg": DESTINATION / "ch5_test_recall_at_5.svg",
        SOURCE_ROOT / "phase15/validation_ablation.svg": DESTINATION / "ch5_validation_ablation.svg",
        SOURCE_ROOT / "phase15/error_distribution.svg": DESTINATION / "ch5_error_distribution.svg",
        DESTINATION / "phase16_agent_medical.png": DESTINATION / "ch5_agent_medical.png",
    }
    for source, destination in copies.items():
        if source.resolve() != destination.resolve():
            shutil.copy2(source, destination)

    assets = [overview, *copies.values()]
    provenance = {
        "ch5_dataset_overview.png": [
            "term_paper/knowledge_rag/artifacts/figures/phase11/medquad_question_types.png",
            "term_paper/knowledge_rag/artifacts/figures/phase11/finqa_split_distribution.png",
            "term_paper/knowledge_rag/artifacts/figures/phase11/wikidata_claim_distribution.png",
        ],
        "ch5_graph_schema.svg": ["term_paper/knowledge_rag/artifacts/figures/phase13/graph_schema.svg"],
        "ch5_test_recall_at_5.svg": ["term_paper/knowledge_rag/artifacts/figures/phase15/test_recall_at_5.svg"],
        "ch5_validation_ablation.svg": ["term_paper/knowledge_rag/artifacts/figures/phase15/validation_ablation.svg"],
        "ch5_error_distribution.svg": ["term_paper/knowledge_rag/artifacts/figures/phase15/error_distribution.svg"],
        "ch5_agent_medical.png": ["term_paper/report/assets/ch5_knowledge_rag/phase16_agent_medical.png"],
    }
    manifest = {
        "schema_version": 1,
        "phase": 17,
        "generated_on": "2026-10-13",
        "files": [
            {
                "path": path.relative_to(WORKSPACE).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
                "derived_from": provenance[path.name],
            }
            for path in assets
        ],
    }
    (DESTINATION / "asset_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"status": "PASS", "assets": len(assets)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
