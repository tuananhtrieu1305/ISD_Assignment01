"""Verify Phase 18 manuscript restructuring and deployment migration."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any, Mapping

from term_paper.tools.build_phase18_manuscript import SECTION_FILENAMES


WORKSPACE = Path(__file__).resolve().parents[2]
REPORT_ROOT = WORKSPACE / "term_paper/report"
BASELINE_SHA256 = "0c82a1e90d394420a7143534ca2b06ebc912648b1c9ea17dd58784d095ce1e9d"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def expected_top_level_order() -> list[str]:
    return [
        "TÓM TẮT",
        "MỞ ĐẦU",
        "CHƯƠNG 1. LỊCH SỬ PHÁT TRIỂN TRÍ TUỆ NHÂN TẠO",
        "CHƯƠNG 2. CÁC KỸ THUẬT MACHINE LEARNING CƠ BẢN",
        "CHƯƠNG 3. CONVOLUTIONAL NEURAL NETWORK",
        "CHƯƠNG 4. RECURRENT NEURAL NETWORK",
        "CHƯƠNG 5. KNOWLEDGE BASE, KNOWLEDGE GRAPH VÀ RETRIEVAL-AUGMENTED GENERATION",
        "KẾT LUẬN",
        "TÀI LIỆU THAM KHẢO",
    ]


def validate_heading_sequence(headings: list[str]) -> list[str]:
    failures: list[str] = []
    if any("TRIỂN KHAI MÔ HÌNH" in heading.upper() or heading.upper().startswith("DEPLOYMENT") for heading in headings):
        failures.append("Standalone deployment Heading 1 is still present")
    if headings != expected_top_level_order():
        failures.append(f"Top-level order mismatch: {headings}")
    return failures


def validate_deployment_distribution(sections: Mapping[str, str]) -> list[str]:
    requirements = {
        "02_ml_co_ban.md": ["## 2.9. Triển khai", "21", "health", "hash", "y khoa"],
        "03_cnn.md": ["## 3.9. Triển khai", "PNG", "JPEG", "top-3", "confidence"],
        "04_rnn.md": ["## 4.9. Triển khai", "8 × 5", "30 × 5", "naive last-Close"],
        "05_knowledge_rag.md": ["## 5.6. Triển khai Agent", "retriever", "citation", "từ chối"],
    }
    failures: list[str] = []
    for filename, markers in requirements.items():
        text = sections.get(filename, "")
        missing = [marker for marker in markers if marker.lower() not in text.lower()]
        if missing:
            failures.append(f"{filename} thiếu nội dung deploy: {missing}")
    return failures


def validate_manifest(manifest: Mapping[str, Any]) -> list[str]:
    failures: list[str] = []
    section_names = [Path(item["path"]).name for item in manifest.get("sections", [])]
    if section_names != SECTION_FILENAMES:
        failures.append(f"Section manifest order mismatch: {section_names}")
    if manifest.get("phase") != 18 or manifest.get("schema_version") != 2:
        failures.append("Manifest must identify Phase 18 schema version 2")
    page_budget = manifest.get("page_budget", {})
    estimate = page_budget.get("estimated_total_before_appendices", 0)
    low, high = page_budget.get("overall_allowed_range", [82, 90])
    if not low <= estimate <= high:
        failures.append(f"Page estimate {estimate} is outside {low}-{high}")
    citations = manifest.get("citations", {})
    if citations.get("count") != 57 or citations.get("missing") or citations.get("orphan"):
        failures.append("Citation manifest must contain 57 entries with no missing/orphan key")
    figures = manifest.get("figures", [])
    tables = manifest.get("tables", [])
    if len(figures) != 22 or len({item["number"] for item in figures}) != 22:
        failures.append("Expected 22 uniquely numbered figures")
    if len(tables) != 21 or len({item["number"] for item in tables}) != 21:
        failures.append("Expected 21 uniquely numbered tables")
    datasets = manifest.get("datasets", [])
    if len(datasets) != 11 or {item.get("chapter") for item in datasets} != {"2", "3", "4", "5"}:
        failures.append("Source registry must contain 11 rows covering Chapters 2-5")
    return failures


def run_verification(workspace: Path) -> dict[str, Any]:
    workspace = Path(workspace)
    report_root = workspace / "term_paper/report"
    manuscript_path = report_root / "manuscript.md"
    manifest_path = report_root / "report_manifest.json"
    manuscript = manuscript_path.read_text(encoding="utf-8")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    checks: list[dict[str, Any]] = []

    def check(name: str, passed: bool, detail: Any) -> None:
        checks.append({"name": name, "status": "PASS" if passed else "FAIL", "detail": detail})

    headings = re.findall(r"(?m)^# ([^#].+)$", manuscript)
    heading_failures = validate_heading_sequence(headings)
    check("top_level_order", not heading_failures, heading_failures or headings)

    source_sections = {
        name: (report_root / "sections" / name).read_text(encoding="utf-8")
        for name in ("02_ml_co_ban.md", "03_cnn.md", "04_rnn.md", "05_knowledge_rag.md")
    }
    deployment_failures = validate_deployment_distribution(source_sections)
    check("deployment_distributed", not deployment_failures, deployment_failures or ["2.9", "3.9", "4.9", "5.6"])
    check(
        "standalone_source_excluded_but_preserved",
        (report_root / "sections/05_trien_khai.md").is_file()
        and "PHẦN 5. TRIỂN KHAI MÔ HÌNH" not in manuscript,
        "legacy source retained outside manuscript",
    )

    manifest_failures = validate_manifest(manifest)
    check("manifest_contract", not manifest_failures, manifest_failures or "Phase 18 schema/counts")
    check(
        "manuscript_hash",
        manifest["manuscript"]["sha256"] == sha256_file(manuscript_path),
        manifest["manuscript"]["sha256"],
    )

    references = re.findall(r"(?m)^\[(\d+)\]\s", manuscript)
    check("references_sequential", references == [str(number) for number in range(1, 58)], f"{len(references)} references")
    used = {
        int(number)
        for group in re.findall(r"\[((?:\d+(?:,\s*)?)+)\]", manuscript)
        for number in re.findall(r"\d+", group)
    }
    check("every_reference_cited", set(range(1, 58)).issubset(used), sorted(set(range(1, 58)) - used))

    crossref_failures: list[str] = []
    for item in [*manifest["figures"], *manifest["tables"]]:
        label = "Hình" if item in manifest["figures"] else "Bảng"
        occurrences = len(re.findall(rf"{label}\s+{re.escape(item['number'])}(?!\d)", manuscript))
        if occurrences < 2:
            crossref_failures.append(f"{label} {item['number']}:{occurrences}")
    check("figure_table_cross_references", not crossref_failures, crossref_failures or "all captions cited in prose")

    asset_failures: list[str] = []
    for item in manifest["figures"]:
        path = report_root / item["path"]
        if not path.is_file() or sha256_file(path) != item["sha256"]:
            asset_failures.append(item["number"])
    for item in manifest["tables"]:
        if not all((workspace / source).exists() for source in item["source_artifacts"]):
            asset_failures.append(item["number"])
    check("artifact_integrity", not asset_failures, asset_failures or "figure hashes and table evidence verified")

    baseline = report_root / "Tieu_luan_AI_ML_CNN_RNN.docx"
    check("baseline_docx_unchanged", baseline.is_file() and sha256_file(baseline) == BASELINE_SHA256, sha256_file(baseline))
    test_run = json.loads(
        (workspace / "term_paper/knowledge_rag/artifacts/manifests/phase15_test_run.json").read_text(encoding="utf-8")
    )
    check(
        "phase15_test_not_rerun",
        test_run.get("status") == "COMPLETE" and test_run.get("run_count") == 1,
        {"status": test_run.get("status"), "run_count": test_run.get("run_count")},
    )

    required_content = [
        "RQ4",
        "Knowledge Graph",
        "Retrieval-Augmented Generation",
        "B4 đạt Recall@5",
        "không phải khuyến nghị đầu tư",
        "không phải chẩn đoán y khoa",
    ]
    missing_content = [marker for marker in required_content if marker not in manuscript]
    check("front_matter_intro_conclusion_updated", not missing_content, missing_content or required_content)

    config_text = (workspace / "term_paper/config/report_outline.md").read_text(encoding="utf-8")
    requirements_text = (workspace / "term_paper/config/requirements_matrix.md").read_text(encoding="utf-8")
    config_ok = (
        "Phiên bản: 2.0" in config_text
        and "Chương 5. Knowledge Base" in config_text
        and "EXP-21" in requirements_text
        and "2.9; 3.9; 4.9; 5.6" in requirements_text
    )
    check("outline_requirements_v2", config_ok, "outline v2 and framework/deployment mappings")

    builder_text = (report_root / "build_report.py").read_text(encoding="utf-8")
    validator_text = (report_root / "validate_report.py").read_text(encoding="utf-8")
    script_ok = (
        "Tieu_luan_AI_ML_CNN_RNN_KG_RAG.docx" in builder_text
        and "AI / ML / CNN / RNN / KG-RAG" in builder_text
        and "expected_counts" in validator_text
        and "== 73" not in validator_text
        and "== 125" not in validator_text
    )
    check("docx_scripts_dynamic", script_ok, "new title/output and manifest-derived counts")

    forbidden = re.findall(r"(?i)\b(?:TODO|TBD|PLACEHOLDER)\b|[A-Za-z]:\\", manuscript)
    check("content_hygiene", not forbidden and "[@" not in manuscript, forbidden or "no placeholders, paths or raw citation keys")

    passed = all(item["status"] == "PASS" for item in checks)
    return {
        "phase": 18,
        "status": "PASS" if passed else "FAIL",
        "checks_passed": sum(item["status"] == "PASS" for item in checks),
        "checks_total": len(checks),
        "manuscript": {
            "sha256": sha256_file(manuscript_path),
            "word_count": manifest["manuscript"]["word_count"],
            "estimated_pages": manifest["page_budget"]["estimated_total_before_appendices"],
            "figures": len(manifest["figures"]),
            "tables": len(manifest["tables"]),
            "references": manifest["citations"]["count"],
        },
        "checks": checks,
    }


def main() -> int:
    report = run_verification(WORKSPACE)
    output = WORKSPACE / "term_paper/knowledge_rag/artifacts/manifests/phase18_verification.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
