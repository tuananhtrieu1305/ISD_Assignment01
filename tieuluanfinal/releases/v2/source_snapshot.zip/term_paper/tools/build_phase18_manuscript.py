"""Build the Phase 18 manuscript after distributing deployment content."""

from __future__ import annotations

import csv
import json
import re
import shutil
from datetime import date
from pathlib import Path
from typing import Any

from term_paper.tools.build_phase7_manuscript import (
    clean_latex,
    format_reference,
    image_dimensions,
    parse_bibtex,
    replace_citations,
    sha256,
    word_count,
)


WORKSPACE = Path(__file__).resolve().parents[2]
TERM_ROOT = WORKSPACE / "term_paper"
REPORT_ROOT = TERM_ROOT / "report"
BIB_PATH = TERM_ROOT / "sources/bibliography.bib"
REGISTRY_PATH = TERM_ROOT / "sources/source_registry.csv"
MANUSCRIPT_PATH = REPORT_ROOT / "manuscript.md"
REFERENCES_PATH = REPORT_ROOT / "references_ordered.md"
MANIFEST_PATH = REPORT_ROOT / "report_manifest.json"
BASELINE_DOCX = REPORT_ROOT / "Tieu_luan_AI_ML_CNN_RNN.docx"

SECTION_FILENAMES = [
    "front_matter.md",
    "00_mo_dau.md",
    "01_lich_su_ai.md",
    "02_ml_co_ban.md",
    "03_cnn.md",
    "04_rnn.md",
    "05_knowledge_rag.md",
    "06_ket_luan.md",
]

TABLE_EVIDENCE = {
    "2.1": ["term_paper/artifacts/metrics/ch2_dataset_summary.csv"],
    "2.2": ["term_paper/artifacts/manifests/ch2"],
    "2.3": ["term_paper/src/scratch/mlp.py", "term_paper/src/keras_impl/mlp.py", "term_paper/src/pytorch_impl/mlp.py"],
    "2.4": ["term_paper/artifacts/metrics/ch2_framework_summary.csv"],
    "2.5": ["term_paper/artifacts/metrics/ch2_best_vs_classical.csv"],
    "3.1": ["term_paper/artifacts/metrics/ch3_dataset_summary.csv"],
    "3.2": ["term_paper/config/ch3_experiment.json"],
    "3.3": ["term_paper/src/scratch/cnn.py", "term_paper/src/keras_impl/cnn.py", "term_paper/src/pytorch_impl/cnn.py"],
    "3.4": ["term_paper/artifacts/metrics/ch3_framework_summary.csv"],
    "3.5": ["term_paper/artifacts/metrics/ch3_a05_architecture_ablation.csv"],
    "4.1": ["term_paper/artifacts/metrics/ch4_dataset_summary.csv"],
    "4.2": ["term_paper/config/ch4_experiment.json"],
    "4.3": ["term_paper/artifacts/metrics/ch4_framework_summary.csv"],
    "4.4": ["term_paper/artifacts/metrics/ch4_framework_summary.csv"],
    "4.5": ["term_paper/artifacts/metrics/ch4_framework_comparison.csv"],
    "5.1": ["term_paper/sources/source_registry.csv", "term_paper/knowledge_rag/artifacts/metrics/phase11_data_audit.json"],
    "5.2": ["term_paper/knowledge_rag/artifacts/metrics/phase13_graph_statistics.json"],
    "5.3": ["term_paper/knowledge_rag/config/phase14_locked.json", "term_paper/knowledge_rag/config/phase15_locked.json"],
    "5.4": ["term_paper/knowledge_rag/artifacts/metrics/phase15_test_metrics.json"],
    "5.5": ["term_paper/knowledge_rag/artifacts/metrics/phase15_case_studies.jsonl", "term_paper/knowledge_rag/phase16_deployment_report.md"],
    "K.1": [
        "term_paper/artifacts/metrics/ch2_framework_summary.csv",
        "term_paper/artifacts/metrics/ch2_best_vs_classical.csv",
        "term_paper/artifacts/metrics/ch3_framework_summary.csv",
        "term_paper/artifacts/metrics/ch3_a05_architecture_ablation.csv",
        "term_paper/artifacts/metrics/ch4_framework_summary.csv",
        "term_paper/knowledge_rag/artifacts/metrics/phase15_test_metrics.json",
        "term_paper/knowledge_rag/artifacts/metrics/phase15_bootstrap_ci.csv",
    ],
}


def section_paths() -> list[Path]:
    return [
        REPORT_ROOT / name if name == "front_matter.md" else REPORT_ROOT / "sections" / name
        for name in SECTION_FILENAMES
    ]


def estimate_pages(*, words: int, figures: int, tables: int, references: int) -> float:
    """Estimate pre-appendix A4 pages from content counts, not a fixed release number."""
    return round(6.0 + words / 620.0 + figures * 0.50 + tables * 0.33 + references * 0.10, 1)


def copy_legacy_figure_assets() -> None:
    for chapter in ("ch2", "ch3", "ch4"):
        source_dir = TERM_ROOT / "artifacts/figures" / chapter
        destination = REPORT_ROOT / "assets" / chapter
        destination.mkdir(parents=True, exist_ok=True)
        for source in sorted(source_dir.glob("*.png")):
            shutil.copy2(source, destination / source.name)


def normalize_image_paths(text: str) -> str:
    for chapter in ("ch2", "ch3", "ch4"):
        text = text.replace(f"../../artifacts/figures/{chapter}/", f"assets/{chapter}/")
    return text.replace("../assets/", "assets/")


def collect_figures(text: str) -> list[dict[str, Any]]:
    lines = text.splitlines()
    figures: list[dict[str, Any]] = []
    for index, line in enumerate(lines):
        match = re.search(r"!\[([^\]]*)\]\(([^)]+)\)", line)
        if not match:
            continue
        alt, relative = match.groups()
        candidates = [alt, *lines[index + 1 : min(index + 6, len(lines))]]
        caption = None
        for candidate in candidates:
            plain = candidate.replace("**", "").replace("*", "").strip()
            caption = re.search(r"Hình\s+([1-5]\.\d+)\.\s*(.+)", plain)
            if caption:
                break
        if not caption:
            raise ValueError(f"Figure without numbered caption near line {index + 1}: {relative}")
        path = REPORT_ROOT / relative
        if not path.is_file():
            raise FileNotFoundError(path)
        figures.append(
            {
                "number": caption.group(1),
                "caption": re.sub(r"\s+", " ", caption.group(2)).strip(" ."),
                "path": relative.replace("\\", "/"),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
                **image_dimensions(path),
            }
        )
    return figures


def collect_tables(text: str) -> list[dict[str, Any]]:
    tables: list[dict[str, Any]] = []
    pattern = r"\*\*Bảng\s+((?:[2-5]\.\d+)|K\.1)\.\s*([^*]+)\*\*"
    for number, caption in re.findall(pattern, text):
        evidence = TABLE_EVIDENCE.get(number)
        if not evidence:
            raise KeyError(f"No evidence mapping for table {number}")
        missing = [relative for relative in evidence if not (WORKSPACE / relative).exists()]
        if missing:
            raise FileNotFoundError(f"Missing evidence for table {number}: {missing}")
        tables.append({"number": number, "caption": caption.strip(), "source_artifacts": evidence})
    return tables


def main() -> int:
    copy_legacy_figure_assets()
    paths = section_paths()
    section_texts = [path.read_text(encoding="utf-8").strip() for path in paths]
    body_with_keys = normalize_image_paths("\n\n<!-- SECTION_BREAK -->\n\n".join(section_texts))
    bib_entries = parse_bibtex(BIB_PATH.read_text(encoding="utf-8"))
    body, citation_order = replace_citations(body_with_keys, bib_entries)
    missing = [key for key in citation_order if key not in bib_entries]
    orphan = [key for key in bib_entries if key not in citation_order]
    if missing or orphan:
        raise ValueError(f"Bibliography mismatch: missing={missing}, orphan={orphan}")

    reference_lines = ["# TÀI LIỆU THAM KHẢO"]
    reference_lines.extend(
        format_reference(index, bib_entries[key]) for index, key in enumerate(citation_order, start=1)
    )
    references = "\n\n".join(reference_lines).strip() + "\n"
    REFERENCES_PATH.write_text(references, encoding="utf-8")
    manuscript = body.rstrip() + "\n\n<!-- SECTION_BREAK -->\n\n" + references
    MANUSCRIPT_PATH.write_text(manuscript, encoding="utf-8")

    figures = collect_figures(manuscript)
    tables = collect_tables(manuscript)
    if len({item["number"] for item in figures}) != len(figures):
        raise ValueError("Duplicate figure number detected")
    if len({item["number"] for item in tables}) != len(tables):
        raise ValueError("Duplicate table number detected")

    section_manifest = []
    for path, source in zip(paths, section_texts):
        section_manifest.append(
            {
                "path": path.relative_to(WORKSPACE).as_posix(),
                "sha256": sha256(path),
                "word_count": word_count(source),
                "headings": re.findall(r"^#{1,3}\s+(.+)$", source, flags=re.MULTILINE),
            }
        )
    code_lengths = [
        len([line for line in block.strip("\n").splitlines() if line.strip()])
        for block in re.findall(r"```[^\n]*\n(.*?)```", manuscript, flags=re.DOTALL)
    ]
    with REGISTRY_PATH.open(encoding="utf-8", newline="") as stream:
        registry = list(csv.DictReader(stream))
    page_estimate = estimate_pages(
        words=word_count(manuscript), figures=len(figures), tables=len(tables), references=len(citation_order)
    )
    manifest = {
        "schema_version": 2,
        "phase": 18,
        "generated_on": date.today().isoformat(),
        "manuscript": {
            "path": MANUSCRIPT_PATH.relative_to(WORKSPACE).as_posix(),
            "sha256": sha256(MANUSCRIPT_PATH),
            "bytes": MANUSCRIPT_PATH.stat().st_size,
            "word_count": word_count(manuscript),
        },
        "sections": section_manifest,
        "page_budget": {
            "overall_allowed_range": [82, 90],
            "estimated_total_before_appendices": page_estimate,
            "estimate_status": "IN_BUDGET_PENDING_DOCX_LAYOUT" if 82 <= page_estimate <= 90 else "OUT_OF_BUDGET",
            "basis": {
                "words": word_count(manuscript),
                "figures": len(figures),
                "tables": len(tables),
                "references": len(citation_order),
                "formula": "6 + words/620 + figures*0.50 + tables*0.33 + references*0.10",
            },
        },
        "citations": {
            "style": "numeric_by_first_appearance",
            "count": len(citation_order),
            "order": citation_order,
            "map": {key: index for index, key in enumerate(citation_order, start=1)},
            "missing": missing,
            "orphan": orphan,
            "bibliography_source": BIB_PATH.relative_to(WORKSPACE).as_posix(),
            "ordered_references": REFERENCES_PATH.relative_to(WORKSPACE).as_posix(),
        },
        "figures": figures,
        "tables": tables,
        "datasets": registry,
        "code_excerpts": {"count": len(code_lengths), "line_counts": code_lengths, "allowed_lines_per_excerpt": [10, 25]},
        "experiment_evidence": {
            "matched_runs_chapters_2_4": 63,
            "test_prediction_rows_chapters_2_4": 287253,
            "chapter5_test_queries": {"medical": 62, "finance": 1147},
            "phase15_test_run_count": 1,
        },
        "migration": {
            "standalone_deployment_included": False,
            "distributed_targets": ["2.9", "3.9", "4.9", "5.6"],
            "legacy_source": "term_paper/report/sections/05_trien_khai.md",
        },
        "baseline_release": {
            "path": BASELINE_DOCX.relative_to(WORKSPACE).as_posix(),
            "sha256": sha256(BASELINE_DOCX),
            "bytes": BASELINE_DOCX.stat().st_size,
        },
        "terminology_policy": "term_paper/report/terminology.md",
        "quality_contract": {
            "content_placeholders_allowed": False,
            "absolute_machine_paths_allowed": False,
            "negative_results_retained": True,
            "standalone_deployment_heading_allowed": False,
        },
    }
    MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(
        f"Built {MANUSCRIPT_PATH.relative_to(WORKSPACE)}: {manifest['manuscript']['word_count']} words, "
        f"{len(figures)} figures, {len(tables)} tables, {len(citation_order)} references, "
        f"estimated {page_estimate} pages."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
