"""Verify the evidence and presentation contract for Phase 17 Chapter 5."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any


EXPECTED_H2 = [f"5.{number}" for number in range(1, 8)]
LOCKED_PHASE15_SHA256 = "560c671a3920bd6bde9f7fc005f3c952f857c55969c989bb6109932623210c9e"
CH5_BIBLIOGRAPHY_KEYS = {
    "benabacha2019medquad",
    "chen2021finqa",
    "cormack2009rrf",
    "deerwester1990lsa",
    "edge2024graphrag",
    "hogan2021knowledgegraphs",
    "lewis2020rag",
    "medquad2023repo",
    "robertson1994okapi",
    "vrandecic2014wikidata",
    "w3c2014rdfconcepts",
    "wikidata2026copyright",
    "wikidata2026dataaccess",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def extract_citation_keys(text: str) -> list[str]:
    """Return citation keys in first-appearance order."""
    ordered: list[str] = []
    for group in re.findall(r"\[@[^\]]+\]", text):
        for key in re.findall(r"@([A-Za-z0-9_:-]+)", group):
            if key not in ordered:
                ordered.append(key)
    return ordered


def bibliography_keys(text: str) -> set[str]:
    return set(re.findall(r"^@\w+\{([^,]+),", text, flags=re.MULTILINE))


def count_words(text: str) -> int:
    clean = re.sub(r"```.*?```", " ", text, flags=re.DOTALL)
    clean = re.sub(r"https?://\S+", " ", clean)
    clean = re.sub(r"!\[[^\]]*\]\([^)]+\)", " ", clean)
    return len(re.findall(r"(?u)\b[\wÀ-ỹ]+\b", clean))


def estimate_pages(text: str) -> float:
    """Estimate A4 pages using the locked 11.5 pt/1.5-line style budget."""
    figures = len(re.findall(r"!\[[^\]]*\]\([^)]+\)", text))
    tables = len(re.findall(r"(?m)^\*\*Bảng\s+5\.\d+\.", text))
    return round(count_words(text) / 520.0 + figures * 0.35 + tables * 0.25, 2)


def _visual_source_failures(lines: list[str]) -> list[str]:
    failures: list[str] = []
    for index, line in enumerate(lines):
        figure = re.search(r"!\[[^\]]*\]\([^)]+\)", line)
        table = re.match(r"^\*\*Bảng\s+(5\.\d+)\.", line)
        if not figure and not table:
            continue
        nearby = "\n".join(lines[index : min(index + 24, len(lines))])
        if "Nguồn:" not in nearby:
            label = table.group(1) if table else f"dòng {index + 1}"
            failures.append(f"Hình/bảng {label} thiếu dòng nguồn/provenance")
    return failures


def validate_chapter(text: str, bibliography: str, report_root: Path) -> tuple[list[str], dict[str, Any]]:
    """Validate the chapter independently from generated experiment code."""
    failures: list[str] = []
    h1 = re.findall(r"(?m)^# (.+)$", text)
    if len(h1) != 1 or not h1[0].startswith("CHƯƠNG 5."):
        failures.append("Chương phải có đúng một Heading 1 bắt đầu bằng 'CHƯƠNG 5.'")

    h2 = re.findall(r"(?m)^## (5\.\d+)\.", text)
    for required in EXPECTED_H2:
        if h2.count(required) != 1:
            failures.append(f"Thiếu hoặc trùng mục {required}")
    unexpected = [item for item in h2 if item not in EXPECTED_H2]
    if unexpected:
        failures.append(f"Có Heading 2 ngoài dải 5.1-5.7: {unexpected}")
    if re.search(r"(?m)^#### ", text):
        failures.append("Không được dùng Heading 4 trong thân bài")

    figure_paths = re.findall(r"!\[[^\]]*\]\(([^)]+)\)", text)
    table_count = len(re.findall(r"(?m)^\*\*Bảng\s+5\.\d+\.", text))
    if len(figure_paths) > 6:
        failures.append("Chương 5 vượt giới hạn 6 hình")
    if table_count > 5:
        failures.append("Chương 5 vượt giới hạn 5 bảng")
    failures.extend(_visual_source_failures(text.splitlines()))

    section_dir = Path(report_root) / "sections"
    missing_assets: list[str] = []
    for relative in figure_paths:
        if not (section_dir / relative).resolve().is_file():
            missing_assets.append(relative)
    if missing_assets:
        failures.append(f"Thiếu asset hình: {missing_assets}")

    cited = extract_citation_keys(text)
    known = bibliography_keys(bibliography)
    missing_citations = sorted(set(cited) - known)
    if missing_citations:
        failures.append(f"Citation key chưa có trong bibliography: {missing_citations}")

    summary = {
        "word_count": count_words(text),
        "estimated_pages": estimate_pages(text),
        "figure_count": len(figure_paths),
        "table_count": table_count,
        "citation_count": len(cited),
        "citation_keys": cited,
    }
    return failures, summary


def _required_literal_checks(text: str, metrics: dict[str, Any]) -> list[str]:
    failures: list[str] = []
    required_literals = [
        "11.274 XML",
        "47.441 QA",
        "247 tài liệu",
        "762 đoạn",
        "9.200 câu hỏi",
        "86.421 đoạn",
        "1.336 đỉnh",
        "99.355 đỉnh",
        "B0",
        "B1",
        "B2",
        "B3",
        "B4",
        "không phải tư vấn y khoa",
        "không phải khuyến nghị đầu tư",
    ]
    for literal in required_literals:
        if literal not in text:
            failures.append(f"Thiếu nội dung bắt buộc: {literal}")

    for domain in ("medical", "finance"):
        query_count = metrics["test"][domain]["B4"]["query_count"]
        if f"{query_count:,}".replace(",", ".") not in text:
            failures.append(f"Thiếu TEST query count của {domain}: {query_count}")
        for model in ("B0", "B1", "B2", "B3", "B4"):
            recall = metrics["test"][domain][model]["chunk_recall_at_5"]
            literal = f"{recall:.3f}".replace(".", ",")
            if literal not in text:
                failures.append(f"Thiếu Recall@5 {domain}/{model}: {literal}")
    return failures


def run_verification(workspace: Path) -> dict[str, Any]:
    workspace = Path(workspace)
    report_root = workspace / "term_paper/report"
    chapter_path = report_root / "sections/05_knowledge_rag.md"
    bib_path = workspace / "term_paper/sources/bibliography.bib"
    metrics_path = workspace / "term_paper/knowledge_rag/artifacts/metrics/phase15_test_metrics.json"
    asset_manifest_path = report_root / "assets/ch5_knowledge_rag/asset_manifest.json"
    checks: list[dict[str, Any]] = []

    def check(name: str, passed: bool, detail: Any) -> None:
        checks.append({"name": name, "status": "PASS" if passed else "FAIL", "detail": detail})

    text = chapter_path.read_text(encoding="utf-8")
    bibliography = bib_path.read_text(encoding="utf-8")
    failures, summary = validate_chapter(text, bibliography, report_root)
    check("chapter_structure_and_traceability", not failures, failures or summary)
    check("page_budget_estimate", 12.0 <= summary["estimated_pages"] <= 15.0, summary["estimated_pages"])
    check("visual_budget", summary["figure_count"] <= 6 and summary["table_count"] <= 5, summary)
    chapter_keys = set(summary["citation_keys"])
    citation_delta = {
        "missing_from_chapter": sorted(CH5_BIBLIOGRAPHY_KEYS - chapter_keys),
        "unexpected_ch5_keys": sorted(chapter_keys - CH5_BIBLIOGRAPHY_KEYS),
    }
    check(
        "chapter5_bibliography_no_orphans",
        not citation_delta["missing_from_chapter"] and not citation_delta["unexpected_ch5_keys"],
        citation_delta,
    )

    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    metric_failures = _required_literal_checks(text, metrics)
    check("dataset_and_metric_literals", not metric_failures, metric_failures or "dataset/TEST values present")
    check(
        "phase15_lock_cited",
        LOCKED_PHASE15_SHA256 in text and metrics.get("config_sha256") == LOCKED_PHASE15_SHA256,
        metrics.get("config_sha256"),
    )

    test_run = json.loads(
        (workspace / "term_paper/knowledge_rag/artifacts/manifests/phase15_test_run.json").read_text(encoding="utf-8")
    )
    check(
        "phase15_test_still_one_shot",
        test_run.get("status") == "COMPLETE" and test_run.get("run_count") == 1,
        {"status": test_run.get("status"), "run_count": test_run.get("run_count")},
    )

    asset_manifest = json.loads(asset_manifest_path.read_text(encoding="utf-8"))
    asset_failures: list[str] = []
    for item in asset_manifest.get("files", []):
        path = workspace / item["path"]
        if not path.is_file():
            asset_failures.append(f"missing:{item['path']}")
        elif path.stat().st_size != item["size_bytes"]:
            asset_failures.append(f"size:{item['path']}")
        elif sha256_file(path) != item["sha256"]:
            asset_failures.append(f"hash:{item['path']}")
    check("asset_manifest_integrity", len(asset_manifest.get("files", [])) == 6 and not asset_failures, asset_failures or "6 assets")

    unsafe_claims = [
        phrase for phrase in ("loại bỏ hallucination", "chẩn đoán bệnh", "bảo đảm lợi nhuận") if phrase in text.lower()
    ]
    check("claim_safety", not unsafe_claims, unsafe_claims or "no unsupported medical/finance claims")

    passed = all(item["status"] == "PASS" for item in checks)
    return {
        "phase": 17,
        "status": "PASS" if passed else "FAIL",
        "checks_passed": sum(item["status"] == "PASS" for item in checks),
        "checks_total": len(checks),
        "chapter": summary,
        "checks": checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    workspace = Path(__file__).resolve().parents[2]
    report = run_verification(workspace)
    output = workspace / "term_paper/knowledge_rag/artifacts/manifests/phase17_verification.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
