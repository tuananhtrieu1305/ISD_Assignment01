"""Verify Phase 10 baseline protection, environment choice and migration coverage."""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path
from typing import Any


WORKSPACE = Path(__file__).resolve().parents[2]
KR_ROOT = WORKSPACE / "term_paper" / "knowledge_rag"
MANIFEST_ROOT = KR_ROOT / "artifacts" / "manifests"
BASELINE_PATH = MANIFEST_ROOT / "phase10_baseline.json"
ENVIRONMENT_PATH = MANIFEST_ROOT / "environment_audit.json"
MIGRATION_PATH = MANIFEST_ROOT / "report_migration_map.csv"
VERIFICATION_PATH = MANIFEST_ROOT / "phase10_verification.json"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_baseline_records(workspace: Path, records: list[dict[str, Any]]) -> list[str]:
    failures: list[str] = []
    seen: set[str] = set()
    for index, record in enumerate(records, start=1):
        required = {"path", "role", "size_bytes", "sha256"}
        missing = required.difference(record)
        if missing:
            failures.append(f"baseline record {index} missing keys: {sorted(missing)}")
            continue
        relative = str(record["path"])
        if relative in seen:
            failures.append(f"duplicate baseline path: {relative}")
            continue
        seen.add(relative)
        path = workspace / relative
        if not path.is_file():
            failures.append(f"baseline file missing: {relative}")
            continue
        if path.stat().st_size != int(record["size_bytes"]):
            failures.append(f"size mismatch: {relative}")
        if sha256_file(path) != record["sha256"]:
            failures.append(f"SHA-256 mismatch: {relative}")
    return failures


def validate_migration_rows(rows: list[dict[str, str]]) -> list[str]:
    failures: list[str] = []
    required_columns = {
        "source_kind",
        "source_id",
        "source_path",
        "source_label",
        "action",
        "destination",
        "status",
        "notes",
    }
    required_kinds = {"heading", "figure", "table", "deployment_use_case"}
    allowed_actions = {"KEEP", "UPDATE", "DISTRIBUTE", "MOVE", "ADD"}
    seen: set[tuple[str, str]] = set()
    for index, row in enumerate(rows, start=1):
        missing = required_columns.difference(row)
        if missing:
            failures.append(f"migration row {index} missing columns: {sorted(missing)}")
            continue
        identity = (row["source_kind"], row["source_id"])
        if identity in seen:
            failures.append(f"duplicate migration identity: {identity}")
        seen.add(identity)
        if row["action"] not in allowed_actions:
            failures.append(f"invalid action for {identity}: {row['action']}")
        if not row["destination"].strip():
            failures.append(f"empty destination for {identity}")
        if row["status"] != "LOCKED":
            failures.append(f"unlocked migration row: {identity}")
        if not row["source_label"].strip():
            failures.append(f"empty source label for {identity}")
    present_kinds = {row.get("source_kind", "") for row in rows}
    for missing_kind in sorted(required_kinds.difference(present_kinds)):
        failures.append(f"missing migration source kind: {missing_kind}")
    required_deployment_ids = {
        "dep-architecture",
        "dep-provenance",
        "dep-diabetes",
        "dep-eurosat",
        "dep-rnn",
        "dep-tests",
        "dep-runtime",
        "dep-limitations",
    }
    deployment_ids = {row["source_id"] for row in rows if row.get("source_kind") == "deployment_use_case"}
    if deployment_ids != required_deployment_ids:
        failures.append(f"deployment mapping mismatch: {sorted(deployment_ids)}")
    return failures


def validate_environment_audit(audit: dict[str, Any]) -> list[str]:
    failures: list[str] = []
    if audit.get("schema_version") != 1:
        failures.append("environment schema_version must be 1")
    render = audit.get("render_target", {})
    if not all(render.get(key) for key in ("runtime", "plan", "region")):
        failures.append("Render target is incomplete")
    selected = audit.get("selected_stack", {})
    for key in ("sparse_retriever", "dense_retriever", "graph_runtime", "answer_mode"):
        if not selected.get(key):
            failures.append(f"selected stack missing {key}")
    if selected.get("external_api_required") is not False:
        failures.append("external API must not be required")
    if len(audit.get("selection_rationale", [])) < 2:
        failures.append("selection rationale is insufficient")
    smoke = audit.get("smoke_benchmark", {})
    if smoke.get("status") != "PASS" or smoke.get("document_count", 0) < 1 or smoke.get("query_count", 0) < 1:
        failures.append("CPU smoke benchmark did not pass")
    return failures


def _load_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def run_verification(workspace: Path = WORKSPACE) -> dict[str, Any]:
    failures: list[str] = []
    for path in (BASELINE_PATH, ENVIRONMENT_PATH, MIGRATION_PATH, KR_ROOT / "README.md"):
        if not path.is_file():
            failures.append(f"required artifact missing: {path.relative_to(workspace).as_posix()}")
    if failures:
        return {"schema_version": 1, "phase": 10, "status": "FAIL", "failures": failures, "checks": []}

    baseline = json.loads(BASELINE_PATH.read_text(encoding="utf-8"))
    environment = json.loads(ENVIRONMENT_PATH.read_text(encoding="utf-8"))
    rows = _load_csv(MIGRATION_PATH)
    checks: list[dict[str, Any]] = []

    def check(name: str, passed: bool, detail: str) -> None:
        checks.append({"name": name, "status": "PASS" if passed else "FAIL", "detail": detail})
        if not passed:
            failures.append(f"{name}: {detail}")

    baseline_failures = validate_baseline_records(workspace, baseline.get("records", []))
    check("baseline_hashes", not baseline_failures, f"{baseline.get('record_count', 0)} records; failures={baseline_failures}")
    roles = {record.get("role") for record in baseline.get("records", [])}
    required_roles = {"protected_release", "manuscript", "manuscript_section", "report_build_or_verifier", "backend_source", "web_source", "legacy_deployment_source", "neo4j_prototype"}
    check("baseline_roles", required_roles.issubset(roles), f"roles={sorted(str(role) for role in roles)}")
    protected = baseline.get("protected_release", {})
    release_path = workspace / protected.get("path", "missing")
    release_ok = release_path.is_file() and release_path.stat().st_size == protected.get("size_bytes") and sha256_file(release_path) == protected.get("sha256")
    check("protected_release", release_ok and protected.get("page_count") == 73, f"path={protected.get('path')}; pages={protected.get('page_count')}; sha256={protected.get('sha256')}")

    migration_failures = validate_migration_rows(rows)
    check("migration_schema", not migration_failures, f"{len(rows)} rows; failures={migration_failures}")
    expected = baseline["content_counts"]
    actual = {
        kind: sum(row["source_kind"] == kind for row in rows)
        for kind in ("heading", "figure", "table", "deployment_use_case")
    }
    expected_counts = {
        "heading": expected["headings"],
        "figure": expected["figures"],
        "table": expected["tables"],
        "deployment_use_case": expected["deployment_use_cases"],
    }
    check("migration_coverage", actual == expected_counts, f"actual={actual}; expected={expected_counts}")
    rnn_heading = [row for row in rows if row["source_kind"] == "heading" and row["source_label"] == "CHƯƠNG 4. RECURRENT NEURAL NETWORK"]
    check("rnn_stays_chapter4", len(rnn_heading) == 1 and rnn_heading[0]["action"] == "KEEP" and "Chương 4" in rnn_heading[0]["destination"], str(rnn_heading))
    deployment_h1 = [row for row in rows if row["source_kind"] == "heading" and "PHẦN 5. TRIỂN KHAI" in row["source_label"]]
    check("standalone_deployment_removed_safely", len(deployment_h1) == 1 and deployment_h1[0]["action"] == "DISTRIBUTE", str(deployment_h1))

    environment_failures = validate_environment_audit(environment)
    check("environment_contract", not environment_failures, f"failures={environment_failures}")
    render = environment["render_target"]
    check("render_free_budget", render.get("cpu") == 0.1 and render.get("ram_bytes") == 512 * 1024 * 1024 and render.get("filesystem") == "ephemeral", str(render))
    selected = environment["selected_stack"]
    check("cpu_portable_stack", selected["dense_retriever"].startswith("scikit_learn") and "pure_python" in selected["sparse_retriever"] and environment["resource_budgets"]["render_process_peak_ram_bytes"] < render["ram_bytes"], str(selected))
    smoke = environment["smoke_benchmark"]
    check("smoke_retrieval", smoke["status"] == "PASS" and smoke["bm25"]["top1_correct"] == 3 and smoke["tfidf_svd_lsa"]["top1_correct"] == 3, str(smoke))

    readme = (KR_ROOT / "README.md").read_text(encoding="utf-8")
    readme_markers = ["Chương 4 — RNN", "Chương 5 — Knowledge", "pure_python_bm25", "TruncatedSVD", protected.get("sha256", "")]
    check("readme_decisions", all(marker in readme for marker in readme_markers), f"markers={readme_markers}")

    return {
        "schema_version": 1,
        "phase": 10,
        "status": "PASS" if not failures else "FAIL",
        "checks": checks,
        "failures": failures,
        "protected_release_sha256": protected.get("sha256"),
        "baseline_record_count": baseline.get("record_count"),
        "migration_row_count": len(rows),
    }


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
    result = run_verification()
    VERIFICATION_PATH.parent.mkdir(parents=True, exist_ok=True)
    VERIFICATION_PATH.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Phase 10 verification: {result['status']} ({len(result['checks'])} checks, {len(result['failures'])} failures)")
    for check in result["checks"]:
        print(f"{check['status']}: {check['name']} — {check['detail']}")
    if result["failures"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
