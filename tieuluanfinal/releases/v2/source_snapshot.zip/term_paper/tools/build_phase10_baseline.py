"""Build the Phase 10 baseline, environment audit and report migration map."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import pickle
import platform
import re
import shutil
import subprocess
import sys
import time
import tracemalloc
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any


WORKSPACE = Path(__file__).resolve().parents[2]
TERM_ROOT = WORKSPACE / "term_paper"
REPORT_ROOT = TERM_ROOT / "report"
KR_ROOT = TERM_ROOT / "knowledge_rag"
MANIFEST_ROOT = KR_ROOT / "artifacts" / "manifests"
BASELINE_PATH = MANIFEST_ROOT / "phase10_baseline.json"
ENVIRONMENT_PATH = MANIFEST_ROOT / "environment_audit.json"
MIGRATION_PATH = MANIFEST_ROOT / "report_migration_map.csv"

EXCLUDED_PARTS = {
    ".venv",
    "node_modules",
    "dist",
    "__pycache__",
    ".pytest_cache",
    "coverage",
    "qa_phase8",
    "qa_phase9",
    "renders",
}
EXCLUDED_SUFFIXES = {".cover", ".pyc", ".pyo"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source_files(root: Path) -> list[Path]:
    if not root.exists():
        return []
    return sorted(
        path
        for path in root.rglob("*")
        if path.is_file()
        and not EXCLUDED_PARTS.intersection(path.relative_to(root).parts)
        and path.suffix.lower() not in EXCLUDED_SUFFIXES
    )


def parse_manuscript_inventory(text: str) -> dict[str, list[dict[str, Any]]]:
    lines = text.splitlines()
    headings: list[dict[str, Any]] = []
    figures: list[dict[str, Any]] = []
    tables: list[dict[str, Any]] = []
    current_h1 = ""

    for line_number, line in enumerate(lines, start=1):
        heading_match = re.match(r"^(#{1,3})\s+(.+?)\s*$", line)
        if heading_match:
            level = len(heading_match.group(1))
            label = heading_match.group(2).strip()
            if level == 1:
                current_h1 = label
            headings.append(
                {
                    "source_id": f"heading-{len(headings) + 1:03d}",
                    "level": level,
                    "label": label,
                    "line": line_number,
                    "section": current_h1,
                }
            )

        image_match = re.search(r"!\[([^\]]*)\]\(([^)]+)\)", line)
        if image_match:
            alt, image_path = image_match.groups()
            caption = alt.strip()
            number_match = re.search(r"Hình\s+([0-9]+\.[0-9]+)", caption)
            if not number_match:
                for candidate in lines[line_number : min(line_number + 5, len(lines))]:
                    candidate_match = re.search(r"Hình\s+([0-9]+\.[0-9]+)\.?\s*(.*)", candidate)
                    if candidate_match:
                        number_match = candidate_match
                        caption = re.sub(r"^[*_]+|[*_]+$", "", candidate).strip()
                        break
            if not number_match:
                raise ValueError(f"Cannot resolve figure number near line {line_number}: {line}")
            number = number_match.group(1)
            figures.append(
                {
                    "source_id": f"figure-{number}",
                    "number": number,
                    "label": caption,
                    "line": line_number,
                    "path": image_path,
                    "section": current_h1,
                }
            )

        table_match = re.match(r"^\*\*Bảng\s+([0-9K]+\.[0-9]+)\.\s*(.+?)\*\*\s*$", line)
        if table_match:
            number, caption = table_match.groups()
            tables.append(
                {
                    "source_id": f"table-{number}",
                    "number": number,
                    "label": f"Bảng {number}. {caption}",
                    "line": line_number,
                    "section": current_h1,
                }
            )

    return {"headings": headings, "figures": figures, "tables": tables}


def _heading_destination(item: dict[str, Any]) -> tuple[str, str, str]:
    label = item["label"]
    section = item["section"]
    if "PHẦN 5. TRIỂN KHAI" in section:
        if "5.2" in label or "diabetes" in label.lower():
            return "DISTRIBUTE", "Chương 2 — mục deploy ngắn", "Giữ use case ML và cảnh báo y khoa."
        if "5.3" in label or "EuroSAT" in label:
            return "DISTRIBUTE", "Chương 3 — mục deploy ngắn", "Giữ use case CNN và giới hạn confidence."
        if "5.4" in label or "RNN" in label or "AAPL" in label:
            return "DISTRIBUTE", "Chương 4 — mục deploy ngắn", "Giữ customer/AAPL, naive baseline và cảnh báo tài chính."
        if "PHẦN 5" in label:
            return "DISTRIBUTE", "Chương 2–5 và Phụ lục PL.D", "Bỏ Heading 1 deployment sau khi mọi nội dung có đích mới."
        return "DISTRIBUTE", "Phụ lục PL.D và ghi chú ngắn cuối Chương 2–5", "Giữ provenance, test và hướng dẫn vận hành nhưng rút gọn trong thân bài."
    if label == "TÓM TẮT":
        return "UPDATE", "TÓM TẮT", "Bổ sung Chương 5, ba dataset và B0–B4."
    if label == "MỞ ĐẦU" or section == "MỞ ĐẦU":
        return "UPDATE", "MỞ ĐẦU", "Cập nhật phạm vi, câu hỏi nghiên cứu và cấu trúc năm chương."
    if "CHƯƠNG 2" in section:
        return "KEEP", "Chương 2", "Giữ numbering; thêm mục deploy ngắn ở cuối chương."
    if "CHƯƠNG 3" in section:
        return "KEEP", "Chương 3", "Giữ numbering; thêm mục deploy ngắn ở cuối chương."
    if "CHƯƠNG 4" in section:
        return "KEEP", "Chương 4 — RNN", "Giữ nguyên numbering RNN; thêm mục deploy ngắn ở cuối chương."
    if section == "KẾT LUẬN":
        return "UPDATE", "KẾT LUẬN sau Chương 5", "Bổ sung kết quả và giới hạn KG–RAG."
    if section == "TÀI LIỆU THAM KHẢO":
        return "UPDATE", "TÀI LIỆU THAM KHẢO", "Bổ sung nguồn KG/RAG và dataset mới."
    return "KEEP", section or "Front matter/Chương 1", "Giữ nội dung và numbering hiện có."


def build_migration_rows(inventory: dict[str, list[dict[str, Any]]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    source_path = "term_paper/report/manuscript.md"
    for item in inventory["headings"]:
        action, destination, notes = _heading_destination(item)
        rows.append(
            {
                "source_kind": "heading",
                "source_id": item["source_id"],
                "source_path": source_path,
                "source_line": str(item["line"]),
                "source_label": item["label"],
                "action": action,
                "destination": destination,
                "status": "LOCKED",
                "notes": notes,
            }
        )

    for item in inventory["figures"]:
        number = item["number"]
        if number == "5.1":
            action, destination, notes = (
                "MOVE",
                "Phụ lục PL.D — tổng quan deployment cũ",
                "Ảnh tổng quan ba use case được giữ làm bằng chứng; UI Chương 5 sẽ có ảnh riêng.",
            )
        elif number == "5.2":
            action, destination, notes = (
                "MOVE",
                "Chương 4 — mục deploy RNN",
                "Renumber thành hình tiếp theo của Chương 4 khi tích hợp.",
            )
        else:
            prefix = number.split(".", 1)[0]
            action, destination, notes = "KEEP", f"Chương {prefix}", "Giữ figure và provenance hiện có."
        rows.append(
            {
                "source_kind": "figure",
                "source_id": item["source_id"],
                "source_path": source_path,
                "source_line": str(item["line"]),
                "source_label": item["label"],
                "action": action,
                "destination": destination,
                "status": "LOCKED",
                "notes": notes,
            }
        )

    for item in inventory["tables"]:
        number = item["number"]
        if number.startswith("K."):
            action, destination, notes = "UPDATE", "Kết luận", "Mở rộng bảng tổng hợp để có Chương 5."
        else:
            action, destination, notes = "KEEP", f"Chương {number.split('.', 1)[0]}", "Giữ bảng và artifact nguồn hiện có."
        rows.append(
            {
                "source_kind": "table",
                "source_id": item["source_id"],
                "source_path": source_path,
                "source_line": str(item["line"]),
                "source_label": item["label"],
                "action": action,
                "destination": destination,
                "status": "LOCKED",
                "notes": notes,
            }
        )

    deployment_rows = [
        ("dep-architecture", "Kiến trúc input → validate → preprocess → model → response", "Phụ lục PL.D + tóm tắt cuối Chương 2–5"),
        ("dep-provenance", "Model/preprocessor version và SHA-256", "Mở đầu/Phụ lục PL.D + provenance từng chương"),
        ("dep-diabetes", "Use case ML: diabetes risk", "Chương 2 — mục deploy ngắn"),
        ("dep-eurosat", "Use case CNN: EuroSAT", "Chương 3 — mục deploy ngắn"),
        ("dep-rnn", "Use case RNN: customer/AAPL", "Chương 4 — mục deploy ngắn"),
        ("dep-tests", "Health check, invalid input và smoke tests", "Phụ lục PL.D + kiểm thử ngắn cuối Chương 2–5"),
        ("dep-runtime", "Chạy local, Docker và trạng thái Render", "Phụ lục PL.D + README"),
        ("dep-limitations", "Hạn chế khi triển khai", "Tiểu kết/hạn chế Chương 2–5"),
    ]
    for source_id, label, destination in deployment_rows:
        rows.append(
            {
                "source_kind": "deployment_use_case",
                "source_id": source_id,
                "source_path": "term_paper/report/sections/05_trien_khai.md",
                "source_line": "",
                "source_label": label,
                "action": "DISTRIBUTE",
                "destination": destination,
                "status": "LOCKED",
                "notes": "Không xóa nguồn trước khi Phase 18 verifier xác nhận nội dung đã được chuyển.",
            }
        )
    return rows


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def _bm25_rank(corpus: list[str], query: str) -> list[int]:
    documents = [_tokens(document) for document in corpus]
    query_tokens = _tokens(query)
    average_length = sum(map(len, documents)) / len(documents)
    document_frequency = Counter(token for document in documents for token in set(document))
    scores: list[float] = []
    for document in documents:
        counts = Counter(document)
        score = 0.0
        for token in query_tokens:
            frequency = counts[token]
            if not frequency:
                continue
            idf = math.log(1 + (len(documents) - document_frequency[token] + 0.5) / (document_frequency[token] + 0.5))
            denominator = frequency + 1.5 * (1 - 0.75 + 0.75 * len(document) / average_length)
            score += idf * frequency * 2.5 / denominator
        scores.append(score)
    return sorted(range(len(scores)), key=lambda index: (-scores[index], index))


def run_smoke_benchmark() -> dict[str, Any]:
    import numpy as np
    from sklearn.decomposition import TruncatedSVD
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.preprocessing import Normalizer

    corpus = [
        "Diabetes is a chronic disease that occurs when blood glucose is too high.",
        "Symptoms of diabetes include increased thirst frequent urination and fatigue.",
        "Insulin helps glucose move from the bloodstream into cells.",
        "Revenue increased to 120 million dollars in 2024 from 100 million dollars in 2023.",
        "Net income declined because operating expenses increased.",
        "The annual report contains balance sheet assets liabilities and cash flow.",
    ]
    queries = [
        ("symptoms frequent urination diabetes", 1),
        ("revenue change in 2024 and 2023", 3),
        ("what does insulin do with glucose", 2),
    ]
    tracemalloc.start()

    bm25_start = time.perf_counter()
    bm25_ranks = [_bm25_rank(corpus, query) for query, _ in queries]
    bm25_ms = (time.perf_counter() - bm25_start) * 1000

    dense_start = time.perf_counter()
    vectorizer = TfidfVectorizer(stop_words="english", sublinear_tf=True)
    corpus_sparse = vectorizer.fit_transform(corpus)
    svd = TruncatedSVD(n_components=4, random_state=42)
    normalizer = Normalizer(copy=False)
    corpus_dense = normalizer.fit_transform(svd.fit_transform(corpus_sparse))
    build_ms = (time.perf_counter() - dense_start) * 1000
    query_start = time.perf_counter()
    dense_ranks: list[list[int]] = []
    for query, _ in queries:
        query_dense = normalizer.transform(svd.transform(vectorizer.transform([query])))
        scores = np.asarray(corpus_dense @ query_dense[0]).reshape(-1)
        dense_ranks.append(sorted(range(len(scores)), key=lambda index: (-float(scores[index]), index)))
    query_ms = (time.perf_counter() - query_start) * 1000
    _, peak_bytes = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    bm25_correct = sum(rank[0] == gold for rank, (_, gold) in zip(bm25_ranks, queries))
    dense_correct = sum(rank[0] == gold for rank, (_, gold) in zip(dense_ranks, queries))
    serialized_bytes = len(pickle.dumps((vectorizer, svd, corpus_dense), protocol=pickle.HIGHEST_PROTOCOL))
    return {
        "status": "PASS" if bm25_correct == len(queries) and dense_correct == len(queries) else "FAIL",
        "document_count": len(corpus),
        "query_count": len(queries),
        "cpu_only": True,
        "bm25": {
            "implementation": "pure_python_bm25_smoke",
            "top1_correct": bm25_correct,
            "query_ms_total": round(bm25_ms, 3),
            "rankings": bm25_ranks,
        },
        "tfidf_svd_lsa": {
            "dimensions": 4,
            "top1_correct": dense_correct,
            "build_ms": round(build_ms, 3),
            "query_ms_total": round(query_ms, 3),
            "serialized_bytes": serialized_bytes,
            "rankings": dense_ranks,
        },
        "python_peak_traced_bytes": peak_bytes,
        "note": "Micro-smoke validates code path and CPU portability only; it is not a quality result for MedQuAD or FinQA.",
    }


def _run_version(command: list[str]) -> dict[str, Any]:
    executable = shutil.which(command[0])
    if not executable:
        return {"available": False, "path": None, "version": None}
    result = subprocess.run(command, cwd=WORKSPACE, text=True, capture_output=True, check=False)
    output = (result.stdout or result.stderr).strip().splitlines()
    return {"available": result.returncode == 0, "path": executable, "version": output[0] if output else None}


def _probe_python(executable: Path) -> dict[str, Any]:
    if not executable.exists():
        return {"available": False, "path": str(executable)}
    code = """
import importlib.util, json, platform, sys
from importlib.metadata import PackageNotFoundError, version
packages = {'flask':'Flask','numpy':'numpy','pandas':'pandas','sklearn':'scikit-learn','torch':'torch','tensorflow':'tensorflow','networkx':'networkx','sentence_transformers':'sentence-transformers','rank_bm25':'rank-bm25','onnxruntime':'onnxruntime','faiss':'faiss-cpu','pytest':'pytest','coverage':'coverage'}
versions = {}
for module, distribution in packages.items():
    try:
        versions[distribution] = version(distribution) if importlib.util.find_spec(module) else None
    except PackageNotFoundError:
        versions[distribution] = None
print(json.dumps({'available': True, 'path': sys.executable, 'version': sys.version.split()[0], 'platform': platform.platform(), 'packages': versions}))
"""
    result = subprocess.run([str(executable), "-c", code], text=True, capture_output=True, check=False)
    if result.returncode:
        return {"available": False, "path": str(executable), "error": result.stderr.strip()}
    return json.loads(result.stdout)


def _machine_info() -> dict[str, Any]:
    total, used, free = shutil.disk_usage(WORKSPACE)
    memory_total = None
    memory_available = None
    try:
        import ctypes

        class MemoryStatus(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        status = MemoryStatus()
        status.dwLength = ctypes.sizeof(MemoryStatus)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            memory_total = status.ullTotalPhys
            memory_available = status.ullAvailPhys
    except (AttributeError, OSError):
        pass
    return {
        "platform": platform.platform(),
        "machine": platform.machine(),
        "logical_cpu_count": os.cpu_count(),
        "memory_total_bytes": memory_total,
        "memory_available_bytes_at_audit": memory_available,
        "workspace_drive": {"total_bytes": total, "used_bytes": used, "free_bytes": free},
    }


def _git(args: list[str]) -> str:
    result = subprocess.run(["git", *args], cwd=WORKSPACE, text=True, capture_output=True, check=True)
    return result.stdout.strip()


def _baseline_files() -> list[tuple[Path, str]]:
    items: list[tuple[Path, str]] = [
        (REPORT_ROOT / "Tieu_luan_AI_ML_CNN_RNN.docx", "protected_release"),
        (REPORT_ROOT / "manuscript.md", "manuscript"),
        (REPORT_ROOT / "front_matter.md", "manuscript_source"),
        (WORKSPACE / "render.yaml", "render_config"),
        (WORKSPACE / "RENDER_DEPLOY.md", "deployment_documentation"),
    ]
    for path in sorted((REPORT_ROOT / "sections").glob("*.md")):
        items.append((path, "manuscript_section"))
    for name in (
        "build_report.py",
        "validate_report.py",
        "verify_phase9.py",
        "finalize_release_metadata.py",
        "derive_page_map.py",
        "make_contact_sheets.py",
        "word_paginate_export.ps1",
        "render_pdf_winrt.ps1",
    ):
        path = REPORT_ROOT / name
        if path.exists():
            items.append((path, "report_build_or_verifier"))
    for root, role in (
        (WORKSPACE / "backend", "backend_source"),
        (WORKSPACE / "web", "web_source"),
        (TERM_ROOT / "deployment", "legacy_deployment_source"),
        (WORKSPACE / "neo4j_scripts", "neo4j_prototype"),
    ):
        items.extend((path, role) for path in source_files(root))
    deduplicated: dict[str, tuple[Path, str]] = {}
    for path, role in items:
        if path.exists():
            deduplicated[path.resolve().as_posix().lower()] = (path, role)
    return sorted(deduplicated.values(), key=lambda item: item[0].relative_to(WORKSPACE).as_posix())


def build() -> tuple[dict[str, Any], dict[str, Any], list[dict[str, str]]]:
    MANIFEST_ROOT.mkdir(parents=True, exist_ok=True)
    manuscript_text = (REPORT_ROOT / "manuscript.md").read_text(encoding="utf-8")
    inventory = parse_manuscript_inventory(manuscript_text)
    migration_rows = build_migration_rows(inventory)

    baseline_records = []
    for path, role in _baseline_files():
        baseline_records.append(
            {
                "path": path.relative_to(WORKSPACE).as_posix(),
                "role": role,
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    old_validation = json.loads((REPORT_ROOT / "report_validation.json").read_text(encoding="utf-8"))
    baseline = {
        "schema_version": 1,
        "phase": 10,
        "captured_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "git_head": _git(["rev-parse", "HEAD"]),
        "git_status_at_capture": _git(["status", "--short"]).splitlines(),
        "protected_release": {
            "path": "term_paper/report/Tieu_luan_AI_ML_CNN_RNN.docx",
            "sha256": sha256_file(REPORT_ROOT / "Tieu_luan_AI_ML_CNN_RNN.docx"),
            "size_bytes": (REPORT_ROOT / "Tieu_luan_AI_ML_CNN_RNN.docx").stat().st_size,
            "page_count": old_validation.get("page_count", 73),
            "policy": "READ_ONLY_PHASE_10_TO_18",
        },
        "content_counts": {
            "headings": len(inventory["headings"]),
            "heading_levels": dict(Counter(str(item["level"]) for item in inventory["headings"])),
            "figures": len(inventory["figures"]),
            "tables": len(inventory["tables"]),
            "deployment_use_cases": 8,
        },
        "record_count": len(baseline_records),
        "records": baseline_records,
    }

    audit_roots = {}
    for relative in ("backend", "web", "term_paper/deployment", "neo4j_scripts"):
        files = source_files(WORKSPACE / relative)
        audit_roots[relative] = {
            "files": len(files),
            "bytes": sum(path.stat().st_size for path in files),
            "extensions": dict(Counter(path.suffix.lower() or "<none>" for path in files)),
        }
    python_candidates = [
        Path(sys.executable),
        WORKSPACE / "backend" / ".venv" / "Scripts" / "python.exe",
        Path("C:/Users/anhca/anaconda3/envs/tf312/python.exe"),
        Path("C:/Users/anhca/anaconda3/envs/rnn312/python.exe"),
    ]
    seen_python: set[str] = set()
    python_environments = []
    for executable in python_candidates:
        key = str(executable.resolve() if executable.exists() else executable).lower()
        if key not in seen_python:
            seen_python.add(key)
            python_environments.append(_probe_python(executable))

    smoke = run_smoke_benchmark()
    environment = {
        "schema_version": 1,
        "phase": 10,
        "audited_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "machine": _machine_info(),
        "commands": {
            "git": _run_version(["git", "--version"]),
            "node": _run_version(["node", "--version"]),
            "npm": _run_version(["npm", "--version"]),
            "docker": _run_version(["docker", "--version"]),
        },
        "python_environments": python_environments,
        "source_inventory": audit_roots,
        "render_target": {
            "runtime": "python",
            "plan": "free",
            "region": "singapore",
            "cpu": 0.1,
            "ram_bytes": 512 * 1024 * 1024,
            "idle_spin_down_minutes": 15,
            "filesystem": "ephemeral",
            "source_urls": [
                "https://render.com/docs/compute-plans",
                "https://render.com/docs/free",
            ],
            "accessed_at": "2026-10-12",
        },
        "selected_stack": {
            "sparse_retriever": "pure_python_bm25",
            "dense_retriever": "scikit_learn_tfidf_truncated_svd_lsa_128d",
            "optional_multilingual_embedding": "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2 (offline experiment only)",
            "vector_search": "numpy_cosine_on_precomputed_float32_matrix",
            "graph_runtime": "pure_python_adjacency_primary_networkx_optional_offline",
            "answer_mode": "extractive_grounded_with_citations_and_abstention",
            "calculator": "allowlisted_finance_program_interpreter_no_eval",
            "external_api_required": False,
        },
        "model_candidates": [
            {
                "name": "TF-IDF + TruncatedSVD/LSA",
                "status": "SELECTED_REQUIRED",
                "license": "BSD-3-Clause via scikit-learn",
                "dimensions": 128,
                "quality_role": "Reproducible dense baseline; benchmark quality will be measured on MedQuAD/FinQA in Phase 14.",
                "deployment_budget": "30k vocabulary components ≈15.4 MB float32; 60k chunk vectors ≈30.7 MB float32 before metadata.",
                "source_url": "https://scikit-learn.org/stable/modules/decomposition.html",
            },
            {
                "name": "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
                "status": "OPTIONAL_OFFLINE_ABLATION_NOT_RENDER_DEFAULT",
                "license": "Apache-2.0",
                "languages": 50,
                "dimensions": 384,
                "parameters": "0.1B",
                "quality_role": "Cross-lingual semantic-search candidate; only retained if Phase 14 shows measurable gain.",
                "deployment_reason": "Transformer runtime and ~0.1B parameters are unsafe as the default beside existing models on a 512 MB Render instance.",
                "source_url": "https://huggingface.co/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
            },
        ],
        "generator_candidates": [
            {
                "name": "Extractive grounded answer composer",
                "status": "SELECTED_REQUIRED",
                "model_bytes": 0,
                "reason": "Runs without API key/GPU, only cites retrieved IDs and can abstain.",
            },
            {
                "name": "External/local generative LLM adapter",
                "status": "OPTIONAL_DISABLED_BY_DEFAULT",
                "reason": "Must never be required for tests, Render startup or final demo.",
            },
        ],
        "resource_budgets": {
            "render_process_peak_ram_bytes": 400 * 1024 * 1024,
            "packaged_rag_artifacts_bytes": 192 * 1024 * 1024,
            "cold_start_target_seconds_excluding_render_spin_up": 20,
            "reason": "Reserve at least ~112 MB beneath Render free 512 MB for interpreter, Flask and existing model services.",
        },
        "selection_rationale": [
            "The official Render free plan exposes only 0.1 CPU and 512 MB RAM and uses an ephemeral filesystem.",
            "The backend environment already contains NumPy and scikit-learn but not sentence-transformers, ONNX Runtime, FAISS or rank-bm25.",
            "Pure-Python BM25, precomputed float32 LSA vectors and adjacency lists avoid a database, GPU and external API key.",
            "The multilingual MiniLM candidate is retained for offline quality ablation, not as the mandatory Render runtime.",
            "The required answer layer is extractive and citation-bound; generation adapters remain optional.",
        ],
        "reuse_assessment": [
            {"area": "backend/", "decision": "REUSE", "evidence": "Flask factory, CORS allow-list, rate limit, security headers, health and error schema."},
            {"area": "web/", "decision": "REUSE", "evidence": "React Router layout, cards, loading/error components, API URL normalization and established visual style."},
            {"area": "term_paper/deployment/", "decision": "PARTIAL_REUSE", "evidence": "Model hash validation, schema and deterministic demo patterns; legacy static UI/server are not the public deployment target."},
            {"area": "neo4j_scripts/", "decision": "REFERENCE_ONLY", "evidence": "Two 19-line toy prediction graphs; no corpus ingestion, provenance, ontology or graph retrieval."},
            {"area": "render.yaml", "decision": "REUSE_AND_EXTEND_IN_PHASE_16", "evidence": "Existing Python web service + React static service topology is appropriate."},
        ],
        "smoke_benchmark": smoke,
        "documented_limitations": [
            "Node/npm are unavailable on the current shell PATH; package-lock and previous Phase 6 build evidence exist, so this does not block Phase 10.",
            "The smoke corpus is deliberately tiny and cannot establish retrieval quality; real comparison starts after Phase 12 data contracts.",
            "No transformer model was downloaded in Phase 10; this avoids changing the environment before dataset acquisition and keeps Render sizing conservative.",
        ],
    }

    BASELINE_PATH.write_text(json.dumps(baseline, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    ENVIRONMENT_PATH.write_text(json.dumps(environment, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    fieldnames = ["source_kind", "source_id", "source_path", "source_line", "source_label", "action", "destination", "status", "notes"]
    with MIGRATION_PATH.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(migration_rows)
    return baseline, environment, migration_rows


def main() -> None:
    baseline, environment, migration_rows = build()
    counts = baseline["content_counts"]
    print(
        "Phase 10 artifacts built: "
        f"{baseline['record_count']} hashes; {counts['headings']} headings; "
        f"{counts['figures']} figures; {counts['tables']} tables; "
        f"{len(migration_rows)} migration rows; smoke={environment['smoke_benchmark']['status']}"
    )


if __name__ == "__main__":
    main()
