# KẾ HOẠCH THỰC THI TIỂU LUẬN AI V3

> **Trạng thái:** `ACTIVE` — nguồn sự thật duy nhất cho yêu cầu mới từ ngày 2026-10-16.
>
> Phase 0–9 trong `TIEU_LUAN_AI_EXECUTION_PLAN.md` và Phase 10–19 trong
> `CHUONG_5_KNOWLEDGE_RAG_EXECUTION_PLAN.md` là lịch sử đã hoàn thành. Đợt V3 dùng
> **Phase 20–35**. Khi người dùng gõ **`làm phase N`** với `N = 20..35`, phải đọc
> toàn bộ file này, kiểm tra dependency và nhật ký, rồi tự thực hiện đúng phase đó.

## 0. Quy tắc điều hành

Khi nhận lệnh `làm phase N`, trợ lý phải:

1. Đọc file này và mọi `AGENTS.md` áp dụng cho đường dẫn sẽ sửa.
2. Kiểm tra `git status`; không ghi đè thay đổi không liên quan của người dùng.
3. Kiểm tra dependency trong bảng trạng thái. Không tự nhảy sang phase độc lập khác.
4. Dùng dữ liệu, số đo, metric, hình, log và trích dẫn thật; không bịa kết quả.
5. Ưu tiên nguồn dữ liệu chính thức, lưu URL, thời điểm truy cập, phiên bản và SHA-256.
6. Chạy kiểm tra tương xứng rủi ro và lưu artifact có thể tái lập.
7. Cập nhật ngay trạng thái, đầu ra, lệnh kiểm tra, kết quả và sai lệch vào nhật ký cuối file.
8. Chỉ đặt `COMPLETE` khi toàn bộ tiêu chí nghiệm thu đạt. Nếu chưa đạt, giữ
   `IN_PROGRESS`; chỉ dùng `BLOCKED` khi thật sự cần quyết định/quyền truy cập từ người dùng.
9. Không chạy lại tập TEST đã niêm phong chỉ để cải thiện báo cáo. Mọi lần mở TEST phải có log.
10. Trả lời bằng kết quả, file quan trọng, kiểm tra đã chạy và phase hợp lý tiếp theo.

Các lựa chọn nhỏ đã khóa trong kế hoạch không cần hỏi lại. Phải hỏi trước khi dùng dịch vụ
trả phí, API key, gửi dữ liệu ra ngoài, thay đổi phạm vi lớn hoặc viết lại lịch sử Git.

## 1. Hợp đồng yêu cầu V3

### 1.1. Cấu trúc báo cáo bắt buộc

1. Mở đầu.
2. Chương 1 — Lịch sử phát triển trí tuệ nhân tạo.
3. Chương 2 — Các kỹ thuật Machine Learning cơ bản.
4. Chương 3 — Convolutional Neural Network (CNN).
5. Chương 4 — Recurrent Neural Network và Long Short-Term Memory (RNN–LSTM).
6. Chương 5 — Knowledge Base, Knowledge Graph và Retrieval-Augmented Generation.
7. Chương 6 — Hệ đa tác tử (Multi-Agent Systems).
8. Kết luận, tài liệu tham khảo và phụ lục cần thiết.

Chương 1–3 giữ mạch nội dung đã có nhưng được sửa số liệu, dataset, code và hình khi không còn
đạt yêu cầu. Chương 4 phải mở rộng từ RNN thành RNN–LSTM thực nghiệm đầy đủ. Chương 5 giữ nội
dung và kết quả đã khóa, chỉ chỉnh cấu trúc/tích hợp. Chương 6 là chương mới hoàn chỉnh.

**Deployment không phải chương riêng.** Cuối mỗi chương thực nghiệm 2–6 có một mục ngắn về
đóng gói, API/UI, giới hạn triển khai và đường dẫn demo tương ứng.

### 1.2. Dataset và thực nghiệm

- Mỗi chương có 2–3 dataset/corpus/benchmark phù hợp với bản chất chương.
- Mỗi dataset phải có: link, giấy phép/citation, dung lượng file, kích cỡ logic, schema,
  mẫu input/output, phân bố quan trọng, missing/imbalance, nhận xét và hạn chế.
- Chương 1 dùng 3 benchmark lịch sử làm case study, không giả vờ là chương huấn luyện.
- Chương 2–4 mỗi chương có 3 dataset và giao thức đánh giá khóa trước.
- Chương 5 giữ MedQuAD, FinQA và Wikidata đã thu nhận/đánh giá.
- Chương 6 dùng 3 bộ nhiệm vụ diabetes, house price và gold, tái sử dụng snapshot đã khóa;
  không nhân bản dữ liệu thô.
- Mọi split có manifest ID/hash. Tabular dùng stratified/group split khi phù hợp; chuỗi thời gian
  luôn split theo thời gian; không shuffle tương lai về quá khứ.
- Ba implementation trên cùng bài toán dùng cùng preprocessing, split, seed policy, metric và
  budget epoch/patience. Khác biệt bắt buộc phải được ghi rõ.

### 1.3. Ba loại code và quy tắc trên 5 layer

Yêu cầu tối thiểu được diễn giải bảo thủ để tránh tranh cãi khi chấm:

- Chương 2 có MLP `scratch`, `Keras`, `PyTorch` bên cạnh các mô hình ML cổ điển.
- Chương 3 có CNN `scratch`, `Keras`, `PyTorch` trên cả 3 dataset.
- Chương 4 có **sáu họ triển khai**: RNN scratch/Keras/PyTorch và
  LSTM scratch/Keras/PyTorch trên cả 3 dataset.
- Mỗi mạng sâu dùng **ít nhất 6 lớp/khối có tham số học được**. Input, reshape, activation,
  pooling, dropout, normalization không được dùng để đủ số đếm. Báo cáo phải có bảng đếm lớp,
  tensor shape và parameter count tự động kiểm chứng.
- ML cổ điển không bị ép dùng khái niệm layer; yêu cầu này áp dụng cho MLP/CNN/RNN/LSTM.
- Scratch nghĩa là tự hiện thực forward, loss, backward/BPTT, optimizer update và predict bằng
  phép toán mảng; không gọi layer/model/automatic differentiation của Keras hay PyTorch.

Kiến trúc tham chiếu để so sánh công bằng:

| Họ | Tối thiểu khối học được | Quy ước mặc định |
|---|---:|---|
| MLP | 6 | 5 Dense ẩn + Dense đầu ra |
| CNN | 7 | 5 Convolution + 2 Dense |
| RNN | 6 | 3 recurrent layers + 3 Dense |
| LSTM | 6 | 3 LSTM layers + 3 Dense |

Nếu scratch quá chậm, được dùng tập train stratified cố định hoặc giảm resolution đã khai báo,
nhưng không được thay test split. Báo cáo phải tách `full-data track` và `matched-subset track`,
không so thời gian/metric giữa hai track như thể cùng điều kiện.

### 1.4. Hợp các hàm và giải thích hàm

Mỗi mô hình phải có cả hai mức giải thích:

1. **Hợp hàm tổng thể:** biểu diễn dạng `F = f_L ∘ ... ∘ f_2 ∘ f_1`, kèm sơ đồ tensor
   và shape tại từng bước. Với RNN/LSTM phải thể hiện thêm phép lặp theo thời gian và theo tầng.
2. **Từng hàm riêng:** tên/signature, input, output, tham số học được, công thức, vai trò,
   shape, corner case và mapping tới hàm scratch/Keras/PyTorch.

Mỗi notebook/module phải sinh machine-readable `model_contract.json`; báo cáo và web đọc cùng
contract để tránh ba nơi mô tả ba kiến trúc khác nhau.

### 1.5. Câu hỏi nghiên cứu khóa trước

- RQ2: Với dữ liệu bảng, ba cách hiện thực MLP khác nhau thế nào về chất lượng, thời gian,
  bộ nhớ, độ ổn định và độ khó triển khai so với baseline ML cổ điển?
- RQ3: Trên ảnh y khoa/viễn thám/vật thể tự nhiên, CNN scratch, Keras và PyTorch khác nhau
  thế nào khi dùng cùng kiến trúc và split?
- RQ4.1: Vanilla RNN thay đổi ra sao trên chuỗi ngắn/dài và ba miền gold/house/power?
- RQ4.2: LSTM có cải thiện sai số dài hạn và gradient stability so với RNN không?
- RQ5: Giữ các câu hỏi B0–B4 đã khóa của Chương 5; không mở lại TEST để tuning.
- RQ6: Hệ nhiều agent có cải thiện task success, kiểm chứng và độ an toàn so với direct/single
  agent, với chi phí latency/message count nào?

### 1.6. Chính sách trình bày lý thuyết

Phần lý thuyết của tất cả các chương phải ở mức **cơ bản, dễ hiểu và vừa đủ ý**. Mục tiêu là
giúp người đọc hiểu mô hình hoạt động như thế nào và liên hệ được với phần thực nghiệm, không
biến tiểu luận thành tài liệu chứng minh toán học.

Thứ tự trình bày mặc định cho mỗi khái niệm:

1. Bài toán hoặc câu hỏi mà kỹ thuật cần giải quyết.
2. Giải thích trực giác bằng ngôn ngữ thông thường.
3. Sơ đồ luồng dữ liệu hoặc ví dụ nhỏ có input/output cụ thể.
4. Các thành phần chính và vai trò của từng thành phần.
5. Một công thức tối thiểu nếu thật sự cần để hiểu cách tính.
6. Liên hệ trực tiếp tới code, dataset và kết quả thực nghiệm.
7. Ưu điểm, hạn chế và trường hợp nên sử dụng.

Quy tắc dùng công thức:

- Không đưa công thức chỉ để làm nội dung có vẻ học thuật hơn.
- Không trình bày chứng minh dài, khai triển vi phân nhiều bước hoặc ký hiệu không được sử dụng
  trong code/thực nghiệm.
- Mỗi công thức xuất hiện phải được giải thích ngay bằng lời, định nghĩa mọi ký hiệu và có ví dụ
  số hoặc tensor shape đơn giản khi phù hợp.
- Ưu tiên sơ đồ, bảng so sánh, pseudocode ngắn và ví dụ trước công thức.
- Phần “hợp các hàm” chỉ cần biểu diễn chuỗi xử lý ở dạng dễ đọc, ví dụ
  `đầu vào → tiền xử lý → lớp 1 → ... → đầu ra`; ký hiệu
  `F = f_L ∘ ... ∘ f_1` được dùng một lần để đáp ứng yêu cầu và luôn đi cùng sơ đồ bằng lời.
- Công thức bắt buộc giới hạn ở những phần cần thiết cho việc hiểu code scratch: hàm dự đoán,
  loss, cập nhật trọng số, convolution, trạng thái RNN và các cổng LSTM. Chỉ nêu dạng cốt lõi,
  không đưa suy diễn đầy đủ nếu không phục vụ việc hiện thực.
- Chi tiết toán học mở rộng, nếu cần lưu để đối chiếu, đặt trong phụ lục hoặc tài liệu kỹ thuật,
  không làm gián đoạn mạch đọc của chương chính.

Tiêu chí đọc hiểu: một sinh viên đã học lập trình và toán đại cương phải hiểu được ý chính mà
không cần tra thêm tài liệu toán chuyên sâu. Mỗi mục lý thuyết phải trả lời được ba câu hỏi:
“dùng để làm gì?”, “dữ liệu đi qua mô hình như thế nào?” và “kết quả được đánh giá ra sao?”.

## 2. Hiện trạng và vấn đề phải xử lý trước

Snapshot kiểm kê ngày 2026-10-16:

- Git đang theo dõi khoảng 55.865 file; pack/loose object xấp xỉ 1,82 GiB.
- `A05/` khoảng 53 nghìn file/0,95 GiB; phần lớn là dataset và output sinh lại được.
- `term_paper/` khoảng 0,90 GiB; `knowledge_rag/` và output render chiếm phần lớn.
- `backend/.venv/` khoảng 0,48 GiB, là venv duy nhất; chưa có PyTorch/TensorFlow.
- `mobile/` khoảng 0,26 GiB nhưng không còn thuộc sản phẩm đích React web + Python API.
- GPU: NVIDIA GeForce RTX 5050 Laptop, 8 GiB VRAM, compute capability 12.0.
- Python hiện tại 3.12.3; web có `/ml`, `/cnn`, `/rnn`, `/rag`, chưa có Chương 6.
- CNN/RNN hiện hữu chưa đạt quy tắc trên 5 lớp; A06 chưa có huấn luyện LSTM đầy đủ.
- Bản V2 đã phát hành: `term_paper/report/Tieu_luan_AI_ML_CNN_RNN_KG_RAG.docx`,
  86 trang, SHA-256 `d7286dd4867e6216f197414e42fc112a3759621c017839fa9b1491b7c5dbfa51`.

Không xóa mù quáng. Phase 20 phải tạo manifest KEEP/MIGRATE/REGENERATE/REMOVE, đối chiếu hash
và giữ bản V2 trước khi dọn. Kế hoạch này **không cho phép tự viết lại Git history**; việc dùng
Git LFS/filter-repo chỉ là bảo trì tùy chọn cần người dùng phê duyệt riêng.

## 3. Kiến trúc đích của repository

```text
assign/
├── apps/
│   ├── api/                    # Python API, job/inference/comparison
│   └── web/                    # React UI
├── src/
│   ├── common/                 # seed, schemas, metrics, device, artifact I/O
│   ├── ch02_ml/
│   ├── ch03_cnn/
│   ├── ch04_rnn_lstm/
│   ├── ch05_knowledge_rag/
│   └── ch06_multi_agent/
├── experiments/
│   ├── configs/                # immutable experiment configs
│   ├── runners/
│   └── notebooks/              # notebooks mỏng, gọi code trong src
├── data/
│   ├── registry.yaml
│   ├── raw/                    # ignored, immutable after download
│   ├── interim/                # ignored
│   ├── processed/              # ignored hoặc chỉ manifest nhỏ
│   └── splits/                 # versioned IDs/hash, không chứa dữ liệu lớn
├── artifacts/
│   ├── manifests/
│   ├── metrics/
│   ├── figures/
│   └── models/                 # checkpoints lớn ignored
├── report/
│   ├── sections/
│   ├── references/
│   ├── tools/
│   └── build/
├── releases/
│   ├── v2/                     # baseline chỉ đọc
│   └── v3/
├── scripts/                    # bootstrap, doctor, data, train, verify
├── tests/
├── docs/
└── TIEU_LUAN_AI_V3_EXECUTION_PLAN.md
```

Nguồn code nằm trong `src/`; notebook không chứa bản sao độc lập của thuật toán. Raw data,
venv, `node_modules`, checkpoint, cache và render QA không được commit. Artifact nhỏ cần cho
báo cáo được version hóa bằng manifest và hash.

## 4. Ma trận dataset đã chọn

Số dưới đây là thông tin công bố ban đầu. Phase 23 phải đo lại file local và ghi số chính xác.

| Chương | ID | Nguồn chính | Quy mô công bố | Vai trò |
|---|---|---|---:|---|
| 1 | `ch1_iris_history` | UCI Iris | 150 mẫu, 4 feature, 3 lớp | Case study lịch sử phân loại |
| 1 | `ch1_mnist_history` | MNIST/LeCun | 70.000 ảnh, 28×28, 10 lớp | Case study deep learning sớm |
| 1 | `ch1_imagenet_history` | ImageNet/ILSVRC | chỉ metadata/citation | Mốc AlexNet; không tải full dataset |
| 2 | `ch2_cdc_diabetes` | UCI CDC Diabetes Health Indicators, DOI 10.24432/C53919 | 253.680 mẫu, 21 biến | Phân loại 3 mức/nhị phân, ưu tiên tiểu đường |
| 2 | `ch2_ames_housing` | AmesHousing/project paper | 2.930 bất động sản, 82 trường | Hồi quy giá nhà |
| 2 | `ch2_bank_marketing` | UCI Bank Marketing, DOI 10.24432/C5K306 | 45.211 mẫu, 16 feature | Phân loại mất cân bằng, đối chứng miền |
| 3 | `ch3_idrid` | IDRiD Grand Challenge/IEEE DataPort | 516 ảnh fundus 4288×2848, nhãn DR 5 mức | CNN ảnh tiểu đường |
| 3 | `ch3_eurosat` | EuroSAT/Zenodo | 27.000 ảnh 64×64 RGB, 10 lớp | CNN viễn thám |
| 3 | `ch3_cifar10` | University of Toronto CIFAR-10 | 60.000 ảnh 32×32 RGB, 10 lớp | CNN benchmark vật thể |
| 4 | `ch4_gold_pink_sheet` | World Bank Commodity Markets Pink Sheet monthly | 1960–hiện tại; đo lại khi tải | Forecast giá vàng đa biến theo tháng |
| 4 | `ch4_bis_house_prices` | BIS Selected Residential Property Prices | hơn 300 series, khoảng 60 quốc gia | Forecast chỉ số giá nhà đa chuỗi theo quý |
| 4 | `ch4_household_power` | UCI Household Power, DOI 10.24432/C58K54 | 2.075.259 dòng, 9 biến, 1 phút | Forecast chuỗi dài, kiểm tra RNN/LSTM |
| 5 | `ch5_medquad_diabetes` | MedQuAD snapshot đã khóa | 47.441 QA local; lát cắt 247 query | KG–RAG y khoa/tiểu đường |
| 5 | `ch5_finqa` | FinQA snapshot đã khóa | 8.281 public QA + 919 private-test | KG–RAG tài chính có bảng/số học |
| 5 | `ch5_wikidata_subgraphs` | Wikidata snapshot đã khóa | 10 entity, 2.056 claim local | KG nền có provenance |
| 6 | `ch6_diabetes_tasks` | view từ Ch2 + Ch5 | khóa ở Phase 31 | Router/tool/critic miền tiểu đường |
| 6 | `ch6_house_tasks` | view từ Ames + BIS | khóa ở Phase 31 | Agent phân tích giá nhà |
| 6 | `ch6_gold_tasks` | view từ World Bank Pink Sheet | khóa ở Phase 31 | Agent phân tích chuỗi vàng, không tư vấn đầu tư |

Nguồn tham chiếu chính:

- CDC Diabetes: <https://archive.ics.uci.edu/dataset/891/cdc%2Bdiabetes%2Bhealth%2Bindicators>
- Ames Housing: <https://github.com/topepo/AmesHousing>
- Bank Marketing: <https://archive.ics.uci.edu/dataset/222/bank%2Bmarketing>
- IDRiD: <https://idrid.grand-challenge.org/Data/>
- CIFAR-10: <https://www.cs.toronto.edu/~kriz/cifar.html>
- World Bank Pink Sheet: <https://thedocs.worldbank.org/en/doc/18675f1d1639c7a34d463f59263ba0a2-0050012025/>
- BIS property prices: <https://data.bis.org/bulkdownload>
- UCI Household Power: <https://archive.ics.uci.edu/dataset/235/individual%2Bhousehold%2Belectric%2Bpower%2Bconsumption>

IDRiD có thể yêu cầu chấp nhận điều khoản/tải thủ công từ IEEE DataPort. Phase 23 phải tạo đúng
drop path và verifier. Nếu quyền truy cập không được cấp, không tự thay bằng Kaggle mirror không
rõ license; ghi `PENDING_USER_DOWNLOAD` và tiếp tục các dataset khác.

## 5. Môi trường và chính sách GPU

Runtime chuẩn là **WSL2 Ubuntu 24.04 + Python 3.11 + `uv`**, dùng NVIDIA driver của Windows.
Không lấy native Windows TensorFlow GPU làm chuẩn vì TensorFlow chỉ hỗ trợ GPU native Windows
đến 2.10; bản mới dùng WSL2.

Để vừa đồng nhất thao tác vừa tránh xung đột CUDA:

- `.venv-torch`: NumPy scratch, PyTorch CUDA, EDA, API và công cụ chung.
- `.venv-keras`: Keras với TensorFlow GPU để giữ implementation độc lập thật sự.
- Hai env dùng cùng Python minor, cùng phiên bản package dữ liệu, cùng schema/split/config và
  được điều khiển bằng một bộ lệnh `scripts/bootstrap`, `scripts/doctor`, `scripts/run_experiment`.
- Pin chính xác chỉ được chốt sau probe RTX 5050/sm_120 trong Phase 21; không đoán wheel CUDA.
- Nếu TensorFlow stable chưa hỗ trợ sm_120, fallback được phép là Keras 3 backend PyTorch,
  nhưng phải ghi rõ trong report/UI và không gọi đó là TensorFlow comparison.
- Scratch ưu tiên CPU/NumPy để thể hiện thuật toán. GPU chỉ dùng nếu có backend mảng riêng được
  kiểm chứng; tuyệt đối không che giấu device.
- Tất cả bảng thời gian ghi OS, CPU/GPU, driver, framework, dtype, batch size, warm-up và số lần lặp.

Smoke test bắt buộc: nhận đúng GPU, matrix multiply, CNN forward/backward, stacked RNN
forward/backward, stacked LSTM forward/backward, Keras fit một batch, PyTorch fit một batch,
VRAM telemetry và CPU fallback.

## 6. Hệ đa agent và web đích

### 6.1. Chương 6

Không dựa vào AutoGen cũ làm lõi. Xây một orchestrator nhỏ, xác định được và không yêu cầu API key:

```text
User task
  -> RouterAgent
  -> DiabetesSpecialist | HouseSpecialist | GoldSpecialist
  -> Verifier/CriticAgent
  -> ReporterAgent
```

Ba cấu hình so sánh:

- A0: direct tool/single response, không orchestration.
- A1: router + specialist.
- A2: router + specialist + verifier + reporter.

Metric: routing accuracy, task success, numeric parity, citation/provenance correctness,
unsafe/unsupported claim rate, refusal correctness, latency, message count và peak memory.
LLM local/remote chỉ là adapter tùy chọn; đường chạy deterministic phải hoạt động không API key.

### 6.2. React UI

Thanh điều hướng cấp một:

`Tổng quan | ML | CNN | RNN–LSTM | KG–RAG | Multi-Agent`

Trong mỗi tab kiến thức:

- 3 tab con dataset theo ma trận ở Mục 4;
- Data card: link, size, sample, distribution, nhận xét;
- Theory/Functions: hợp hàm, sơ đồ shape, giải thích từng hàm;
- Run/Compare: chạy inference hoặc job demo cho tất cả implementation hợp lệ;
- Results: metric, confusion/error chart, timing, memory, parameter/layer count;
- Deployment: trạng thái API/model, limitations, artifact hash.

RNN–LSTM phải cho chọn `RNN`/`LSTM` và hiển thị 3 framework song song. UI không huấn luyện full
dataset trên Render; huấn luyện GPU diễn ra offline/local, Render chỉ inference trên checkpoint
đã khóa và các demo job nhỏ. Multi-Agent có trace graph, message timeline, evidence và verifier result.

## 7. Giao thức đánh giá chung

- Seed chuẩn: 42; phase triển khai có thể thêm 3 seed `{17, 42, 73}` cho độ ổn định.
- Validation dùng cho tuning; TEST niêm phong trước tuning và chỉ mở một lần/config release.
- Classification: accuracy, macro-F1, weighted-F1, per-class recall, confusion matrix, AUROC khi hợp lệ.
- Regression/forecast: MAE, RMSE, MAPE/sMAPE khi mẫu số hợp lệ, R² cho tabular; thêm horizon-wise error.
- Efficiency: train wall time, inference p50/p95, peak RAM/VRAM, checkpoint size, parameter count.
- Mỗi metric row chứa dataset version, split hash, code commit, config hash, seed, device và framework.
- So sánh thống kê dùng mean/std trên seed; không tuyên bố hơn hẳn chỉ từ một run.
- Nội dung y khoa chỉ mang tính học thuật, không chẩn đoán. Nội dung vàng không phải khuyến nghị đầu tư.

## 8. Bảng phase

| Phase | Tên | Dependency | Trạng thái |
|---:|---|---|---|
| 20 | Đóng băng V2, kiểm kê và dọn repository | 0–19 | `IN_PROGRESS` |
| 21 | Chuẩn hóa WSL2/GPU và lock môi trường | 20 | `PENDING` |
| 22 | Khóa SRS, kiến trúc, schema và giao thức V3 | 21 | `PENDING` |
| 23 | Thu nhận dataset mới và registry provenance | 22 | `PENDING` |
| 24 | EDA, data card, split và leakage audit | 23 | `PENDING` |
| 25 | Lõi dùng chung, model contract và hợp hàm | 24 | `PENDING` |
| 26 | Chương 2: ML/MLP scratch–Keras–PyTorch | 25 | `PENDING` |
| 27 | Chương 3: CNN scratch–Keras–PyTorch | 25 | `PENDING` |
| 28 | Chương 4A: RNN scratch–Keras–PyTorch | 25 | `PENDING` |
| 29 | Chương 4B: LSTM scratch–Keras–PyTorch | 28 | `PENDING` |
| 30 | Hợp nhất và regression Chương 5 KG–RAG | 25 | `PENDING` |
| 31 | Chương 6: hệ đa agent và benchmark | 26, 29, 30 | `PENDING` |
| 32 | Python API, artifact registry và deploy contract | 26–31 | `PENDING` |
| 33 | React UI nhiều tab và so sánh đồng thời | 32 | `PENDING` |
| 34 | Viết và tích hợp báo cáo 6 chương | 24–33 | `PENDING` |
| 35 | Build DOCX, render QA, release và bàn giao | 34 | `PENDING` |

## 9. Chi tiết từng phase

### Phase 20 — Đóng băng V2, kiểm kê và dọn repository

**Mục tiêu:** có repository gọn, phục hồi được và chỉ còn một đường phát triển V3.

**Công việc:**

1. Hash và sao lưu logic bản DOCX V2 cùng source/manifests tối thiểu vào `releases/v2/`.
2. Sinh inventory theo file/size/tracked/ignored/hash và phân loại:
   `KEEP`, `MIGRATE`, `REGENERATE`, `REMOVE`, `MANUAL_REVIEW`.
3. Khóa whitelist source/notebook/model/report cần giữ từ `pipeline/`, `A05/`, `A06/`,
   `term_paper/`, `backend/`, `web/`; ghi lý do cho từng nhóm.
4. Tạo cấu trúc đích Mục 3; migrate source cần dùng, không copy output nặng.
5. Xóa đúng target đã xác minh: `.venv`, `node_modules`, cache, nested `.git`, render page tạm,
   duplicate raw data/checkpoint/metric, mobile app không còn dùng và output có thể sinh lại.
6. Cập nhật `.gitignore`, README và `docs/repository_manifest.md`.
7. Không rewrite history; báo riêng kích thước working tree và `.git` còn lại.

**Đầu ra:** manifest CSV/JSON, deletion log, keep-list, V2 release hash, cấu trúc V3 sạch.

**Nghiệm thu:** không mất DOCX V2; mọi file xóa có lý do và recovery source; không còn venv,
`node_modules`, cache hay duplicate dataset/model trong cây làm việc; tests nguồn được giữ còn import được.

### Phase 21 — Chuẩn hóa WSL2/GPU và lock môi trường

**Mục tiêu:** một lệnh bootstrap và một lệnh doctor tái tạo được hai env GPU nhất quán.

**Công việc:** kiểm tra WSL/NVIDIA; chốt wheel chính thức hỗ trợ sm_120; tạo lockfiles; cài hai env;
viết PowerShell wrapper và Bash scripts; chạy toàn bộ smoke test GPU/CPU; ghi device manifest.

**Đầu ra:** `pyproject.toml`, lockfiles theo backend, `scripts/bootstrap*`, `scripts/doctor*`,
`artifacts/manifests/environment.json`, hướng dẫn VS Code/Jupyter.

**Nghiệm thu:** fresh bootstrap thành công; PyTorch và Keras train được một batch trên GPU hoặc
fallback Keras được công khai; test CNN/RNN/LSTM backward không lỗi; peak VRAM dưới 8 GiB.

### Phase 22 — Khóa SRS, kiến trúc, schema và giao thức V3

**Mục tiêu:** loại bỏ mơ hồ trước khi tải dữ liệu/huấn luyện.

**Công việc:** tạo requirement traceability matrix; khóa outline 6 chương; API/artifact schemas;
quy tắc layer count; model/data/run contracts; naming; metric; split; TEST seal; page budget dự kiến;
risk register; mapping report–code–web; khóa style guide lý thuyết theo nguyên tắc dễ hiểu,
formula-minimal và quy tắc chuyển phần toán mở rộng xuống phụ lục.

**Đầu ra:** `docs/srs_v3.md`, `docs/traceability_v3.csv`, JSON Schemas, ADRs và architecture diagram.

**Nghiệm thu:** mọi câu yêu cầu của giảng viên/người dùng map tới ít nhất một phase, artifact và test;
không còn thuật ngữ “Keras”/“scratch”/“trên 5 layer” chưa định nghĩa; có checklist kiểm tra mọi
công thức đều cần thiết, được định nghĩa ký hiệu và giải thích bằng lời.

### Phase 23 — Thu nhận dataset mới và registry provenance

**Mục tiêu:** tải snapshot thật, hợp pháp và kiểm chứng được cho toàn bộ ma trận.

**Công việc:** viết downloader idempotent; tải nguồn chính; ghi license/citation/access time/version;
hash từng file; validate schema; lưu manifest; xử lý IDRiD manual drop nếu cần; không tải ImageNet full;
không nhân bản Ch5/Ch6 raw data.

**Đầu ra:** `data/registry.yaml`, raw manifests, dataset cards bản nguồn, download/verify scripts.

**Nghiệm thu:** mỗi dataset có URL, license status, byte size, logical size, SHA-256 và verifier;
mọi file lớn ignored; rerun không tải lại file đúng hash.

### Phase 24 — EDA, data card, split và leakage audit

**Mục tiêu:** tạo phần dữ liệu hoàn chỉnh trước khi mô hình hóa.

**Công việc:** EDA tự động + kiểm tra mẫu; target/class/time distribution; missing/outlier/duplicate;
sample input/output; stratified/group/time split; fit preprocessing chỉ trên train; leakage audit;
ước lượng RAM/VRAM; tạo hình publication-ready.

**Đầu ra:** 2–3 data card/chương, split manifests, preprocessing contracts, EDA tables/figures.

**Nghiệm thu:** mỗi card đủ link/size/sample/distribution/comment/limitations; split hash cố định;
không có ID/time/group leakage; hình và số trong card tái sinh từ script.

### Phase 25 — Lõi dùng chung, model contract và hợp hàm

**Mục tiêu:** ba framework dùng cùng hợp đồng thay vì notebook rời rạc.

**Công việc:** xây seed/device/data/metric/artifact core; model registry; layer/parameter counter;
tensor-shape tracer; schema `model_contract.json`; renderer hợp hàm; trainer hooks; checkpoint metadata;
unit tests gradient/shape/parity trên synthetic tiny data. Renderer phải sinh cả phiên bản kỹ thuật
và phiên bản dễ đọc dạng `input → các bước xử lý → output`, để report/UI không buộc người đọc
phải hiểu ký hiệu toán trước.

**Đầu ra:** `src/common/`, config schemas, equation/function table generator và test suite.

**Nghiệm thu:** contract phát hiện mô hình dưới 6 lớp; output shapes/parameter counts đối chiếu được;
scratch numerical gradient check đạt tolerance; artifact không thiếu provenance.

### Phase 26 — Chương 2: ML/MLP scratch–Keras–PyTorch

**Mục tiêu:** hoàn thiện ba bài toán tabular và phần code Chương 2.

**Công việc:** baseline ML phù hợp; MLP 6 lớp scratch/Keras/PyTorch; cùng split/preprocessing;
train diabetes, Ames, Bank; tuning chỉ validation; calibration/error/fairness proxy hợp lý;
TEST one-shot; sinh bảng/hình/hợp hàm/giải thích hàm và checkpoint demo.

**Nghiệm thu:** 3 dataset × 3 MLP implementation có metric thật; baseline ML riêng; layer count ≥6;
không leakage; bảng so sánh quality/time/RAM-VRAM/size; test inference parity trên sample cố định.

### Phase 27 — Chương 3: CNN scratch–Keras–PyTorch

**Mục tiêu:** CNN đủ sâu trên IDRiD, EuroSAT và CIFAR-10.

**Công việc:** chuẩn hóa image pipeline; augmentation train-only; 5 Conv + 2 Dense; scratch conv,
pool, loss, backward; Keras/PyTorch matched architecture; class weighting cho IDRiD; GPU training;
saliency chỉ dùng như minh họa, không tuyên bố giải thích lâm sàng; TEST one-shot.

**Nghiệm thu:** 3×3 run hợp lệ hoặc scratch matched-subset được dán nhãn rõ; ≥7 learnable layers;
confusion/per-class metrics; layer/shape/function docs; checkpoint inference chạy qua API contract.

### Phase 28 — Chương 4A: RNN scratch–Keras–PyTorch

**Mục tiêu:** Vanilla RNN đầy đủ trên vàng, giá nhà và điện năng.

**Công việc:** tạo causal windows; scaler fit train-only; naive/seasonal baseline; 3 recurrent + 3 Dense;
scratch BPTT và gradient clipping; Keras/PyTorch; multi-horizon evaluation; gradient diagnostics;
khóa config trước TEST.

**Nghiệm thu:** 3 dataset × 3 implementation; ≥6 learnable layers; không future leakage;
metric theo horizon; biểu diễn hợp hàm theo thời gian/tầng; numerical gradient tests trên tiny sequence.

### Phase 29 — Chương 4B: LSTM scratch–Keras–PyTorch

**Mục tiêu:** bổ sung LSTM thật và so trực tiếp với RNN.

**Công việc:** scratch input/forget/output/candidate gates + BPTT; 3 LSTM + 3 Dense;
Keras/PyTorch matched; cùng windows/splits/budget Phase 28; gate/gradient diagnostics;
so RNN–LSTM theo dataset/horizon/efficiency; TEST one-shot.

**Nghiệm thu:** 3 dataset × 3 LSTM implementation; ≥6 learnable layers; gate equations và từng hàm
được giải thích; bảng RNN vs LSTM; kiểm tra gradient/parity/serialization đạt.

### Phase 30 — Hợp nhất và regression Chương 5 KG–RAG

**Mục tiêu:** đưa Chương 5 cũ vào cấu trúc V3 mà không phá vỡ kết quả đã khóa.

**Công việc:** migrate source/artifacts tối thiểu; giữ hash dataset/config/result Phase 11–19;
chạy regression tests không mở lại public TEST; chuẩn hóa data/model contracts; tạo 3 dataset tabs;
chuyển phần Agent cũ thành cầu nối ngắn sang Chương 6; cập nhật deploy mục cuối chương.

**Nghiệm thu:** metric/citation cũ không đổi; public TEST run count không tăng; local retrieval/demo
và API contract hoạt động; Ch5 không còn trình bày Agent như nội dung thay cho Ch6.

### Phase 31 — Chương 6: hệ đa agent và benchmark

**Mục tiêu:** xây và đánh giá A0/A1/A2 trên ba miền ưu tiên.

**Công việc:** task schema; deterministic router; 3 specialist dùng model/RAG tools đã khóa;
critic/verifier; reporter; timeout/retry/error propagation; trace/provenance; bộ câu hỏi fixed;
safety cases; optional local-LLM adapter; benchmark A0/A1/A2 trên cùng task set.

**Nghiệm thu:** chạy không API key; 3 domain mỗi domain có task train/dev/test hoặc fixed eval rõ;
metric task/routing/citation/safety/latency/message; không đưa dự đoán y khoa/tài chính như lời khuyên;
mọi answer truy ngược tới tool call, artifact version và evidence.

### Phase 32 — Python API, artifact registry và deploy contract

**Mục tiêu:** một backend Python ổn định phục vụ toàn bộ UI và Render.

**Công việc:** endpoints chapter/dataset/model/run/compare/job/agent-trace; request validation;
async job/polling cho demo dài; artifact hash verification; CPU-safe loading; health/readiness;
CORS/env config; size/memory budget; Render blueprint; unit/integration/security tests.

**Nghiệm thu:** OpenAPI/schema khớp frontend; invalid input trả lỗi có cấu trúc; artifact hash mismatch
không làm process crash lặp; local GPU mode và Render CPU inference đều chạy; không chứa secret.

### Phase 33 — React UI nhiều tab và so sánh đồng thời

**Mục tiêu:** thay UI hiện tại bằng giao diện học thuật, rõ và có thể demo.

**Công việc:** top-level tabs và 3 dataset subtabs; reusable DataCard/FunctionComposition/
ModelRunner/Comparison/Deployment components; chạy ba implementation cùng input; RNN/LSTM toggle;
agent trace; responsive/accessibility/loading/error/empty states; chart không gây hiểu sai;
Playwright E2E và production build.

**Nghiệm thu:** mỗi tab đủ data/theory/run/results/deploy; CNN và RNN/LSTM hiển thị đúng 3 dataset;
run-all cho kết quả truy nguồn; URL deep-link; refresh không mất route; API error không làm blank page;
build và E2E đạt.

### Phase 34 — Viết và tích hợp báo cáo 6 chương

**Mục tiêu:** hoàn thiện nội dung học thuật từ artifact thật.

**Công việc:** giữ giọng/style mẫu DOCX; cập nhật Ch1–3; viết lại Ch4 RNN–LSTM; regression Ch5;
viết Ch6; chèn data cards, hợp hàm, từng hàm, layer/parameter tables, metrics, error analysis,
limitations; mục deploy ngắn cuối từng chương; cập nhật mục lục/hình/bảng/tài liệu tham khảo.
Mỗi phần lý thuyết phải đi từ trực giác và ví dụ đến sơ đồ, chỉ sau đó mới dùng công thức tối thiểu;
loại bỏ công thức trang trí, chứng minh dài và ký hiệu không được dùng trong code hoặc phân tích.

**Page budget dự kiến:** Mở đầu 3–4; Ch1 khoảng 8; Ch2 12–15; Ch3 12–15;
Ch4 18–22 do gồm RNN và LSTM; Ch5 12–15; Ch6 12–15; kết luận 3–4. Đây là budget trình bày,
không được kéo dài bằng code dump; code đầy đủ nằm trong repo/phụ lục chọn lọc.

**Nghiệm thu:** mọi số liệu truy tới artifact; mỗi yêu cầu trong traceability matrix có bằng chứng;
không còn chương deploy riêng; heading/caption/cross-reference/citation liên tục; không có placeholder;
mọi công thức đều có giải thích bằng lời và định nghĩa ký hiệu; mỗi mục lý thuyết trả lời rõ “dùng để
làm gì?”, “dữ liệu đi qua mô hình như thế nào?” và “đánh giá ra sao?”.

### Phase 35 — Build DOCX, render QA, release và bàn giao

**Mục tiêu:** phát hành một DOCX V3 đã kiểm tra từng trang và source tái lập được.

**Công việc:** build DOCX mới không ghi đè V2; render PDF/PNG; kiểm tra cover/TOC/page break,
overflow, bảng/hình/caption/font, orphan heading, code readability; spell/style/link/citation audit;
chạy tests cuối; smoke deploy; sinh release manifest/hash và hướng dẫn demo.

**Đầu ra chính:** `releases/v3/Tieu_luan_AI_6_chuong.docx`, PDF kiểm tra, release manifest,
demo guide, environment/data/model hashes và test report.

**Nghiệm thu:** render toàn bộ trang không lỗi; navigation target/caption/reference hợp lệ;
DOCX mở được trên Word; web/API production build đạt; V2 nguyên vẹn; hash release được ghi lại.

## 10. Rủi ro và quyết định mặc định

| Rủi ro | Xử lý mặc định |
|---|---|
| RTX 5050/sm_120 chưa được wheel hỗ trợ | Probe official matrix ở Phase 21; không tự compile; CPU fallback có nhãn |
| TensorFlow/Keras và PyTorch xung đột CUDA | Hai venv khóa riêng trong cùng WSL/runtime contract |
| IDRiD cần thao tác tài khoản | Manual drop path + verifier; không dùng mirror không rõ license |
| Scratch CNN/RNN/LSTM quá chậm | Matched-subset cố định; full TEST giữ nguyên; không so chéo track |
| Mô hình >5 lớp overfit dataset nhỏ | Regularization/early stopping trên validation; vẫn báo limitation, không che metric |
| Gold/house series ít điểm | Dùng multivariate/multi-series windows, rolling-origin validation; không random split |
| Render không đủ GPU/RAM | Train local GPU; deploy CPU inference/demo subset; lazy-load và budget artifact |
| Ch5 TEST bị chạy lại | Regression từ artifact/hash, không rerun evaluator TEST |
| Git vẫn lớn sau cleanup | Báo `.git` riêng; history rewrite/LFS cần phê duyệt riêng |
| Multi-agent phụ thuộc LLM/API | Deterministic core bắt buộc; LLM adapter chỉ optional |

## 11. Definition of Done toàn dự án

- Repository gọn, không chứa môi trường/cache/dataset/model/output lớn bị trùng.
- WSL2 GPU chạy được PyTorch và Keras hoặc fallback được công khai, có lockfile và doctor report.
- Tất cả dataset có nguồn, license, hash, size, sample, distribution, comment và limitation.
- Ch2 có MLP scratch/Keras/PyTorch; Ch3 có CNN scratch/Keras/PyTorch; Ch4 có RNN và LSTM,
  mỗi loại scratch/Keras/PyTorch; mọi mạng sâu có ít nhất 6 learnable layers.
- Hợp các hàm và giải thích từng hàm tồn tại trong code contract, report và UI từ cùng một nguồn.
- Lý thuyết được trình bày cơ bản, dễ hiểu, đủ ý; ưu tiên trực giác, sơ đồ và ví dụ; chỉ giữ công
  thức thật sự cần thiết và mọi ký hiệu đều được giải thích.
- Ba implementation được đánh giá công bằng trên 3 dataset/chương, có metric và efficiency thật.
- Ch5 giữ nguyên tính tái lập; Ch6 có multi-agent benchmark thực và chạy không API key.
- React UI có tab chính/tab dataset, run-all, comparison và trace; Python API ổn định trên Render.
- Deployment chỉ là mục ngắn cuối chương, không phải chương riêng.
- DOCX V3 được render/kiểm tra từng trang, V2 còn nguyên, release có SHA-256 và test report.

## 12. Nhật ký thực thi V3

Chỉ thêm dòng khi phase được thực hiện.

| Ngày | Phase | Trạng thái | Tóm tắt | Artifact/kiểm tra |
|---|---:|---|---|---|
| 2026-10-16 | Plan | `COMPLETE` | Lập kế hoạch V3 Phase 20–35 theo yêu cầu mới | `TIEU_LUAN_AI_V3_EXECUTION_PLAN.md` |
| 2026-10-16 | Plan update | `COMPLETE` | Khóa chính sách lý thuyết dễ hiểu, formula-minimal và nghiệm thu khả năng đọc hiểu | Mục 1.6; Phase 22, 25, 34; Definition of Done |

