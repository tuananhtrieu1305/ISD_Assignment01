from apps.api.v3.server import create_app
app = create_app()
